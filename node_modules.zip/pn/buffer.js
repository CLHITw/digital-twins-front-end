var buffer = require("buffer");
module.exports = buffer;