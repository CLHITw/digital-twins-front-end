var vm = require("vm");
module.exports = vm;