var string_decoder = require("string_decoder");
module.exports = string_decoder;