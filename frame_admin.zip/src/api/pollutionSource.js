import request from '@/plugins/request';

export function pollutionSourceList (data) {
    return request({
        url: '/pollution_source/list',
        method: 'get',
        params: data
    });
}

export function pollutionSourceAdd (data) {
    return request({
        url: '/pollution_source/add',
        method: 'post',
        data: data
    });
}

export function pollutionSourceDelete (data) {
    return request({
        url: '/pollution_source/delete',
        method: 'get',
        params: data
    });
}

export function pollutionSourceUpdate (data) {
    return request({
        url: '/pollution_source/update',
        method: 'post',
        data: data
    });
}

export function pollutionSourceImport (data) {
    return request({
        url: '/pollution_source/import',
        method: 'post',
        data: data
    });
}

export function pollutionDealwithFacilities (data) {
    return request({
        url: '/pollution_source/dealwithFacilities',
        method: 'get',
        params: data
    });
}

export function pollutionDealwithWay (data) {
    return request({
        url: '/pollution_source/dealwithWay',
        method: 'get',
        params: data
    });
}

export function pollutionSourceSelect (data) {
    return request({
        url: '/pollution_source/select',
        method: 'get',
        params: data
    });
}

export function pollutionSourceEnterpriseList (data) {
    return request({
        url: '/pollution_source_enterprise/list',
        method: 'get',
        params: data
    });
}

export function pollutionSourceEnterpriseAdd (data) {
    return request({
        url: '/pollution_source_enterprise/add',
        method: 'post',
        data: data
    });
}

export function pollutionSourceEnterpriseDelete (data) {
    return request({
        url: '/pollution_source_enterprise/delete',
        method: 'get',
        params: data
    });
}
