import request from '@/plugins/request';

export function monitorNodeList (data) {
    return request({
        url: '/monitor_node/list',
        method: 'get',
        params: data
    });
}

export function monitorNodeAdd (data) {
    return request({
        url: '/monitor_node/add',
        method: 'post',
        data: data
    });
}

export function monitorNodeDelete (data) {
    return request({
        url: '/monitor_node/delete',
        method: 'get',
        params: data
    });
}

export function monitorNodeUpdate (data) {
    return request({
        url: '/monitor_node/update',
        method: 'post',
        data: data
    });
}

export function monitorNodeImport (data) {
    return request({
        url: '/monitor_node/import',
        method: 'post',
        data: data
    });
}

export function monitorNodeSelect (data) {
    return request({
        url: '/monitor_node/select',
        method: 'get',
        params: data
    });
}
