import request from '@/plugins/request';

export function monitorNodeFluorescenceList (data) {
    return request({
        url: '/monitor_node_fluorescence/list',
        method: 'get',
        params: data
    });
}

export function monitorNodeFluorescenceAdd (data) {
    return request({
        url: '/monitor_node_fluorescence/add',
        method: 'post',
        data: data
    });
}

export function monitorNodeFluorescenceDelete (data) {
    return request({
        url: '/monitor_node_fluorescence/delete',
        method: 'get',
        params: data
    });
}

export function monitorNodeFluorescenceUpdate (data) {
    return request({
        url: '/monitor_node_fluorescence/update',
        method: 'post',
        data: data
    });
}

export function monitorNodeFluorescenceImport (data) {
    return request({
        url: '/monitor_node_fluorescence/import',
        method: 'post',
        data: data
    });
}
