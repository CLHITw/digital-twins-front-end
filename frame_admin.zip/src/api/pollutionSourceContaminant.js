import request from '@/plugins/request';

export function pollutionSourceContaminantList (data) {
    return request({
        url: '/pollution_source_contaminant/list',
        method: 'get',
        params: data
    });
}

export function pollutionSourceContaminantAdd (data) {
    return request({
        url: '/pollution_source_contaminant/add',
        method: 'post',
        data: data
    });
}

export function pollutionSourceContaminantDelete (data) {
    return request({
        url: '/pollution_source_contaminant/delete',
        method: 'get',
        params: data
    });
}

export function pollutionSourceContaminantUpdate (data) {
    return request({
        url: '/pollution_source_contaminant/update',
        method: 'post',
        data: data
    });
}

export function contaminant (data) {
    return request({
        url: '/pollution_source_contaminant/contaminant',
        method: 'post',
        data: data
    });
}

export function pollutionSourceContaminantImport (data) {
    return request({
        url: '/pollution_source_contaminant/import',
        method: 'post',
        data: data
    });
}
