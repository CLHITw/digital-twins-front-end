import request from '@/plugins/request';

export function enterpriseList (data) {
    return request({
        url: '/enterprise/list',
        method: 'get',
        params: data
    });
}

export function enterpriseAdd (data) {
    return request({
        url: '/enterprise/add',
        method: 'post',
        data: data
    });
}

export function enterpriseImport (data) {
    return request({
        url: '/enterprise/import',
        method: 'post',
        data: data
    });
}

export function enterpriseDelete (data) {
    return request({
        url: '/enterprise/delete',
        method: 'get',
        params: data
    });
}

export function enterpriseUpdate (data) {
    return request({
        url: '/enterprise/update',
        method: 'post',
        data: data
    });
}

export function industrySelect (data) {
    return request({
        url: '/enterprise/industry_select',
        method: 'get',
        params: data
    });
}

export function enterpriseSelect (data) {
    return request({
        url: '/enterprise/select',
        method: 'get',
        params: data
    });
}
