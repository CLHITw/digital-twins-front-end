import request from '@/plugins/request';

export function enterpriseOutleList (data) {
    return request({
        url: '/enterprise_outle/list',
        method: 'get',
        params: data
    });
}

export function enterpriseOutleAdd (data) {
    return request({
        url: '/enterprise_outle/add',
        method: 'post',
        data: data
    });
}

export function enterpriseOutleDelete (data) {
    return request({
        url: '/enterprise_outle/delete',
        method: 'get',
        params: data
    });
}

export function enterpriseOutleUpdate (data) {
    return request({
        url: '/enterprise_outle/update',
        method: 'post',
        data: data
    });
}

export function enterpriseOutleImport (data) {
    return request({
        url: '/enterprise_outle/import',
        method: 'post',
        data: data
    });
}

export function outletType (data) {
    return request({
        url: '/enterprise_outle/outlet_type',
        method: 'get',
        params: data
    });
}

export function whereaboutsType (data) {
    return request({
        url: '/enterprise_outle/whereabouts_type',
        method: 'get',
        params: data
    });
}

export function acceptWater (data) {
    return request({
        url: '/enterprise_outle/accept_water',
        method: 'get',
        params: data
    });
}
