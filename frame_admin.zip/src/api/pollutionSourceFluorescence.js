import request from '@/plugins/request';

export function pollutionSourceFluorescenceList (data) {
    return request({
        url: '/pollution_source_fluorescence/list',
        method: 'get',
        params: data
    });
}

export function pollutionSourceFluorescenceAdd (data) {
    return request({
        url: '/pollution_source_fluorescence/add',
        method: 'post',
        data: data
    });
}

export function pollutionSourceFluorescenceDelete (data) {
    return request({
        url: '/pollution_source_fluorescence/delete',
        method: 'get',
        params: data
    });
}

export function pollutionSourceFluorescenceUpdate (data) {
    return request({
        url: '/pollution_source_fluorescence/update',
        method: 'post',
        data: data
    });
}
