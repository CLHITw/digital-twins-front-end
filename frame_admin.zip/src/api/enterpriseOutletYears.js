import request from '@/plugins/request';

export function enterpriseOutletYearsList (data) {
    return request({
        url: '/enterprise_outlet_years/list',
        method: 'get',
        params: data
    });
}

export function enterpriseOutletYearsAdd (data) {
    return request({
        url: '/enterprise_outlet_years/add',
        method: 'post',
        data: data
    });
}

export function enterpriseOutletYearsDelete (data) {
    return request({
        url: '/enterprise_outlet_years/delete',
        method: 'get',
        params: data
    });
}

export function enterpriseOutletYearsDetailList (data) {
    return request({
        url: '/enterprise_outlet_years/detailList',
        method: 'get',
        params: data
    });
}

export function enterpriseOutletYearsDetailAdd (data) {
    return request({
        url: '/enterprise_outlet_years/detailAdd',
        method: 'post',
        data: data
    });
}

export function enterpriseOutletYearsDetailDelete (data) {
    return request({
        url: '/enterprise_outlet_years/detailDelete',
        method: 'get',
        params: data
    });
}

export function enterpriseOutletYearsImport (data) {
    return request({
        url: '/enterprise_outlet_years/import',
        method: 'post',
        data: data
    });
}
