import request from '@/plugins/request';

export function enterprise (data) {
    return request({
        url: '/statistical/enterprise',
        method: 'get',
        params: data
    });
}

export function pollutionSource (data) {
    return request({
        url: '/statistical/pollutionSource',
        method: 'get',
        params: data
    });
}

export function monitorNode (data) {
    return request({
        url: '/statistical/monitorNode',
        method: 'get',
        params: data
    });
}

export function contaminant (data) {
    return request({
        url: '/statistical/contaminant',
        method: 'get',
        params: data
    });
}

export function monitorModeContaminant (data) {
    return request({
        url: '/statistical/monitorModeContaminant',
        method: 'get',
        params: data
    });
}

export function monitorModeFluorescence (data) {
    return request({
        url: '/statistical/monitorModeFluorescence',
        method: 'get',
        params: data
    });
}
