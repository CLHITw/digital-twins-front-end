import request from '@/plugins/request';

export function monitorNodeContaminantList (data) {
    return request({
        url: '/monitor_node_contaminant/list',
        method: 'get',
        params: data
    });
}

export function monitorNodeContaminantAdd (data) {
    return request({
        url: '/monitor_node_contaminant/add',
        method: 'post',
        data: data
    });
}

export function monitorNodeContaminantDelete (data) {
    return request({
        url: '/monitor_node_contaminant/delete',
        method: 'get',
        params: data
    });
}

export function monitorNodeContaminantUpdate (data) {
    return request({
        url: '/monitor_node_contaminant/update',
        method: 'post',
        data: data
    });
}

export function contaminant (data) {
    return request({
        url: '/monitor_node_contaminant/contaminant',
        method: 'post',
        data: data
    });
}

export function monitorNodeContaminantImport (data) {
    return request({
        url: '/monitor_node_contaminant/import',
        method: 'post',
        data: data
    });
}
