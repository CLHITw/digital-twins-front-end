import request from '@/plugins/request';

export function monitorNode (data) {
    return request({
        url: '/sourceCalculate/monitorNode',
        method: 'get',
        params: data
    });
}

export function pollutionSource (data) {
    return request({
        url: '/sourceCalculate/pollutionSource',
        method: 'get',
        params: data
    });
}

export function contaminant (data) {
    return request({
        url: '/sourceCalculate/contaminant',
        method: 'get',
        params: data
    });
}

export function sourceCalculate (data) {
    return request({
        url: '/sourceCalculate/sourceCalculate',
        method: 'post',
        data: data
    });
}

export function sourceHistory (data) {
    return request({
        url: '/sourceCalculate/sourceHistory',
        method: 'post',
        data: data
    });
}

export function fluorescenceType (data) {
    return request({
        url: '/sourceCalculate/fluorescenceType',
        method: 'post',
        data: data
    });
}

export function sourceFluorescence (data) {
    return request({
        url: '/sourceCalculate/sourceFluorescence',
        method: 'post',
        data: data
    });
}
