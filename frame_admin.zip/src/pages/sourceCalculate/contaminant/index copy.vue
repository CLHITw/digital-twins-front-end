<template>
    <div class="conMain">
        <Row :gutter="16">
            <Col span="11" class="kp">
                <Row :gutter="16">
                    <Col span="12">
                        <div class="kpDiv">
                            <p class="cardTitle">
                                <Icon type="ios-apps"></Icon>
                                观测点
                            </p>
                            <Select v-model="monitor_node_arr" multiple @on-change="riverData()">
                                <Option v-for="(item,index) in monitorNodeData" :value="item.id" :key="index">{{ item.name }}</Option>
                            </Select>
                        </div>
                    </Col>
                    <Col span="12">
                        <div class="kpDiv">
                            <p class="cardTitle">
                                <Icon type="ios-bonfire"></Icon>
                                污染源
                            </p>
                            <Select v-model="pollution_source_arr" multiple>
                                <Option v-for="(item,index) in pollutionSourceData" :value="item.id" :key="index">{{ item.name }}</Option>
                            </Select>
                        </div>
                    </Col>
                    <Col span="12">
                        <div class="kpDiv">
                            <p class="cardTitle">
                                <Icon type="ios-flame"></Icon>
                                污染物
                            </p>
                            <p class="kpName">
                                污染物：
                                <Select v-model="contaminant_id" style="width:250px">
                                    <Option v-for="(item,index) in contaminantData" :value="item.id" :key="index">{{ item.name }}</Option>
                                </Select>
                            </p>
                            <p style="margin-top:10px"><span class="kpName">时间段：</span>&nbsp;<DatePicker style="width:250px" type="datetimerange" placeholder="请选择时间段" @on-change="selectTime"></DatePicker></p>
                        </div>
                    </Col>
                    <Col span="12">
                        <div class="kpDiv">
                            <p class="cardTitle">
                                <Icon type="ios-cloud"></Icon>
                                配置
                            </p>
                            <p class="kpName">时间间隔：<Input v-model="time_step" type="number" style="width:70px"/>&nbsp;&nbsp;网络步长：<Input type="number" v-model="mesh_step" style="width:70px"/></p>
                            <p class="kpName" style="margin-top:10px">&nbsp;&nbsp;&nbsp;&nbsp;总时间：<Input type="number" v-model="time_tracking" style="width:70px"/>&nbsp;&nbsp;降解系数：<Input  v-model="k_pollutant_degradation" style="width:100px"/></p>
                        </div>
                    </Col>
                    <Col span="24">
                        <div class="kpDiv">
                            <p class="cardTitle">
                                <Icon type="ios-cube"></Icon>
                                主河道
                            </p>
                            <Row :gutter="10">
                                <Col span="14">
                                    <Table :columns="columnsRiver" :data="mainMakers">
                                        <template slot-scope="{ row }" slot="coordinates">
                                            {{row.LON}},{{row.LAT}}
                                        </template>
                                        <template slot-scope="{ row, index }" slot="action">
                                            <Icon type="md-close" style="cursor: pointer;" @click="removeMain(index,row.SITE)"/>
                                        </template>
                                    </Table>
                                </Col>
                                <Col span="10">
                                    <div style="height:200px">
                                        <el-amap :zoom="zoom" :center="center" :events="mainEvents" mapStyle="dark">
                                            <el-amap-marker  v-for="(marker, index) in mainMakers" :key="index" :position="[marker.LON,marker.LAT]" :content="marker.SITE" :vid="index"></el-amap-marker>
                                        </el-amap>
                                    </div>
                                </Col>
                            </Row>
                        </div>
                    </Col>
                    <Col span="24">
                        <div class="kpDiv">
                            <p slot="title" class="cardTitle">
                                <Icon type="md-git-branch"></Icon>
                                支流
                            </p>
                            <Row :gutter="10">
                                <Col span="14">
                                    <Table :columns="columnsRiver" :data="branchMakers">
                                        <template slot-scope="{ row }" slot="coordinates">
                                            {{row.LON}},{{row.LAT}}
                                        </template>
                                        <template slot-scope="{ row, index }" slot="action">
                                            <Icon type="md-close" style="cursor: pointer;" @click="removeBranch(index,row.SITE)"/>
                                        </template>
                                    </Table>
                                </Col>
                                <Col span="10">
                                    <div style="height:200px">
                                        <el-amap :zoom="zoom" :center="center" :events="branchEvents" mapStyle="dark">
                                            <el-amap-marker  v-for="(marker, index) in branchMakers" :key="index" :position="[marker.LON,marker.LAT]" :content="marker.SITE" :vid="index"></el-amap-marker>
                                        </el-amap>
                                    </div>
                                </Col>
                            </Row>
                        </div>
                    </Col>
                </Row>
                <p style="text-align:center">
                    <Button style="margin-top:20px" type="primary" @click="sourceCalculateAction()">开始溯源</Button>
                </p>
            </Col>
            <Col span="12" style="padding:5px">
                <!-- <dv-border-box-10 :color="['#0a54ea', '#fff']"> -->
                    <div style="padding:30px;box-shadow: inset 0 0 10px #0a54ea;border-radius:5px">
                        <div style="display:flex;align-items: center;color:#fff">
                            <Select style="width:200px;margin-right:20px" @on-change="selectKeyAction">
                                <Option v-for="(item,index) in selectKey" :value="item.value" :key="index">{{ item.label }}</Option>
                            </Select>
                            <Button style="margin-right:20px" type="primary" @click="heatPlay()">{{playTitle}}</Button>
                            <span>{{playIndex}}</span>
                        </div>
                        <div :style="{height:mapHeight,'margin-top':'10px'}" id="sourceMap"></div>
                    </div>
                <!-- </dv-border-box-10> -->
            </Col>
        </Row>
        <div class="compute" v-if="showCompute">
            <dv-border-box-8 :color="['#0a54ea', '#fff']">
                <div style="padding:20px">
                    <div class="siteicon">
                        <img src="@/assets/images/river.png" style="width:100px"/>
                    </div>
                    <p>{{comTitle}}......{{percent}}%</p>
                    <Progress :percent="percent" status="active" hide-info/>
                </div>
            </dv-border-box-8>
        </div>
        <Modal v-model="showMainModel" title="添加主流坐标点" :width="300" @on-ok="mainRiver" :transfer="false">
            <Input v-model="name" placeholder="请输入坐标点名称" />
        </Modal>
        <Modal v-model="showBranchModel" title="添加支流坐标点" :width="300" @on-ok="branchRiver" :transfer="false">
            <Input v-model="name" placeholder="请输入坐标点名称" />
        </Modal>
    </div>
</template>
<script>
    import { mapState } from 'vuex';
    import { monitorNode, pollutionSource, contaminant, sourceCalculate } from '@api/sourceCalculate';
    export default {
        name: 'contaminant',
        data () {
            let self = this;
            return {
                showCompute: false,
                percent: 0,
                monitorNodeData: [],
                pollutionSourceData: [],
                contaminantData: [],
                name: '',
                showMainModel: false,
                showBranchModel: false,
                longitude: '',
                latitude: '',
                window: {},
                zoom: 10,
                center: [113.554177, 23.088718],
                mainMakers: [],
                mainEvents: {
                    click (e) {
                        self.name = ''
                        let { lng, lat } = e.lnglat
                        self.longitude = lng;
                        self.latitude = lat;
                        self.showMainModel = true
                    }
                },
                branchMakers: [],
                branchEvents: {
                    click (e) {
                        self.name = ''
                        let { lng, lat } = e.lnglat
                        self.longitude = lng;
                        self.latitude = lat;
                        self.showBranchModel = true
                    }
                },
                columnsRiver: [
                    {
                        title: '名称',
                        key: 'SITE',
                        width: 150
                    },
                    {
                        title: '经纬度',
                        slot: 'coordinates'
                    },
                    {
                        title: '操作',
                        slot: 'action',
                        align: 'center',
                        width: 70
                    }
                ],
                monitor_node_arr: [],
                pollution_source_arr: [],
                monitorData: [],
                contaminant_id: '',
                start_time: '',
                end_time: '',
                mesh_step: 300,
                time_step: 200,
                time_tracking: 1800,
                k_pollutant_degradation: '0.000006',
                sourceMap: '',
                sourceData: {},
                selectKey: [],
                playData: [],
                heatmap: '',
                timer: '',
                playIndex: 0,
                mapHeight: document.documentElement.clientHeight - 176 + 'px',
                playTitle: '播放',
                comTitle: ''
            }
        },
        computed: {
            ...mapState('admin/layout', [
                'isMobile'
            ])
        },
        methods: {
            mainRiver () {
                if (this.name) {
                    let marker = {
                        LON: this.longitude,
                        LAT: this.latitude,
                        SITE: this.name
                    };
                    this.mainMakers.push(marker)
                } else {
                    this.showMainModel = true;
                    this.$Message['warning']({
                        content: '请输入名称',
                        duration: 3
                    });
                }
            },
            removeMain (index, name) {
                this.$Modal.confirm({
                    title: '删除主流坐标点',
                    content: '确定删除主流坐标点：' + name + '吗？',
                    onOk: async () => {
                        this.mainMakers.splice(index, 1)
                    }
                });
            },
            branchRiver () {
                if (this.name) {
                    let marker = {
                        LON: this.longitude,
                        LAT: this.latitude,
                        SITE: this.name
                    };
                    this.branchMakers.push(marker)
                } else {
                    this.showBranchModel = true;
                    this.$Message['warning']({
                        content: '请输入名称',
                        duration: 3
                    });
                }
            },
            removeBranch (index, name) {
                this.$Modal.confirm({
                    title: '删除支流坐标点',
                    content: '确定删除支流坐标点：' + name + '吗？',
                    onOk: async () => {
                        this.branchMakers.splice(index, 1)
                    }
                });
            },
            // 监测点
            async getMonitorNodeData () {
                let res = await monitorNode();
                if (res.errno === 0) {
                    this.monitorNodeData = res.data
                } else {
                    this.$Message['error']({
                        content: res.errmsg,
                        duration: 3
                    });
                };
            },
            // 污染源
            async getPollutionSourceData () {
                let res = await pollutionSource();
                if (res.errno === 0) {
                    this.pollutionSourceData = res.data
                } else {
                    this.$Message['error']({
                        content: res.errmsg,
                        duration: 3
                    });
                };
            },
            // 污染物
            async getContaminantData () {
                let res = await contaminant();
                if (res.errno === 0) {
                    this.contaminantData = res.data
                } else {
                    this.$Message['error']({
                        content: res.errmsg,
                        duration: 3
                    });
                };
            },
            selectTime (e) {
                this.start_time = e[0];
                this.end_time = e[1]
            },
            sourceCalculateAction () {
                if (this.monitor_node_arr.length === 0) {
                    this.$Message['warning']({
                        content: '监测点不能为空',
                        duration: 3
                    });
                    return;
                }
                if (this.pollution_source_arr.length === 0) {
                    this.$Message['warning']({
                        content: '污染源不能为空',
                        duration: 3
                    });
                    return;
                }
                if (!this.contaminant_id) {
                    this.$Message['warning']({
                        content: '污染物不能为空',
                        duration: 3
                    });
                    return;
                }
                if (!this.start_time || !this.end_time) {
                    this.$Message['warning']({
                        content: '时间段不能为空',
                        duration: 3
                    });
                    return;
                }
                if (this.mainMakers.length === 0) {
                    this.$Message['warning']({
                        content: '主流标记点不能为空',
                        duration: 3
                    });
                    return;
                }
                if (this.branchMakers.length === 0) {
                    this.$Message['warning']({
                        content: '支流标记点不能为空',
                        duration: 3
                    });
                    return;
                }
                this.percent = 0
                this.comTitle = '上传数据'
                this.showCompute = true
                let that = this
                setTimeout(async () => {
                    that.comTitle = '上传数据'
                    that.percent = Math.floor(Math.random() * 10)
                }, 1000)
                setTimeout(async () => {
                    that.comTitle = '分析整理数据'
                    that.percent = Math.floor(Math.random() * 10 + 30)
                }, 3000)
                setTimeout(async () => {
                    that.comTitle = '数据导入算法模型'
                    that.percent = Math.floor(Math.random() * 10 + 50)
                }, 5000)
                setTimeout(async () => {
                    that.comTitle = '算法模型计算'
                    that.percent = Math.floor(Math.random() * 10 + 80)
                    that.getSourceCalculateData();
                }, 6000)
                setTimeout(async () => {
                    that.comTitle = '溯源完成'
                    that.percent = 100
                }, 7000)
            },
            // 监测数据
            async getSourceCalculateData () {
                let params = {
                    monitor_node_arr: this.monitor_node_arr,
                    contaminant_id: this.contaminant_id,
                    start_time: this.start_time,
                    end_time: this.end_time,
                    sources_pollution_arr: this.pollution_source_arr,
                    main_river: this.mainMakers,
                    tributary_river: this.branchMakers,
                    other_params: {
                        mesh_step: parseInt(this.mesh_step),
                        time_step: parseInt(this.time_step),
                        time_tracking: parseInt(this.time_tracking),
                        k_pollutant_degradation: this.k_pollutant_degradation
                    }
                }
                let res = await sourceCalculate(params);
                this.showCompute = false
                if (res.errno === 0) {
                    this.sourceData = res.data;
                    let data = res.data;
                    this.selectKey = [];
                    let selectKey = Object.keys(data)
                    for (var i in selectKey) {
                        let info = {
                            value: selectKey[i],
                            label: selectKey[i]
                        }
                        this.selectKey.push(info)
                    }
                } else {
                    this.$Message['error']({
                        content: res.errmsg,
                        duration: 3
                    });
                };
            },
            selectKeyAction (e) {
                this.playData = [];
                if (this.heatmap) {
                    this.heatmap.setMap(null)
                }
                if (this.timer) {
                    clearInterval(this.timer);
                    this.timer = '';
                }
                this.playIndex = 0;
                let data = this.sourceData[e];
                let time = data.time
                let concentration = data.concentration;
                let location = data.location;
                for (var i in time) {
                    let info = {
                        time: time[i],
                        data: []
                    }
                    for (var j in concentration[i]) {
                        let a = {
                            count: concentration[i][j],
                            lat: location[i][j][1],
                            lng: location[i][j][0]
                        };
                        info.data.push(a)
                    };
                    this.playData.push(info)
                }
                this.sourceMap.setZoomAndCenter(12, [this.playData[0].data[0].lng, this.playData[0].data[0].lat]);
            },
            heatPlay () {
                let that = this;
                if (this.playTitle === '播放') {
                    that.playTitle = '暂停'
                    this.timer = setInterval(() => {
                        if (that.playIndex + 1 > that.playData.length) {
                            clearInterval(that.timer);
                            that.timer = '';
                            that.playTitle = '播放'
                            that.playIndex = 0
                            return
                        }
                        if (this.heatmap) {
                            this.heatmap.setMap(null)
                        }
                        let data = that.playData[that.playIndex].data
                        // 使用插件
                        that.sourceMap.plugin(['AMap.Heatmap'], function () {
                            // 初始化heatmap对象
                            that.heatmap = new AMap.Heatmap(that.sourceMap, {
                                radius: 20, // 给定半径
                                height: 10,
                                gradient: {
                                    0: '#2A85B8',
                                    0.1: '#2A85B8',
                                    0.2: '#16B0A9',
                                    0.3: '#29CF6F',
                                    0.4: '#5CE182',
                                    0.5: '#7DF675',
                                    0.6: '#FFF100',
                                    0.7: '#FAA53F',
                                    1: '#D04343'
                                }
                            })
                            // 设置数据集
                            that.heatmap.setDataSet({
                                data: data, // 坐标数据集  即之前请求到的热力图数据
                                max: 4
                            })
                            // that.sourceMap.on('click', function (e) {
                            //     var feat = that.heatmap.queryFeature([e.pixel.x, e.pixel.y]);
                            //     if (feat) {
                            //         that.sourceMap.clearMap();
                            //         that.sourceMap.add(new AMap.Marker({
                            //             position: feat.lnglat,
                            //             anchor: 'bottom-center',
                            //             content: '<div style="margin-bottom: 15px; border:1px solid #fff; border-radius: 4px;color: #fff; width: 150px; text-align: center;">热力值: ' + feat.value.toFixed(2) + '</div>'
                            //         }));
                            //     }
                            // });
                        })
                        that.playIndex++
                    }, 300);
                } else {
                    clearInterval(that.timer);
                    that.timer = '';
                    that.playTitle = '播放'
                }
            },
            riverData () {
                this.mainMakers = [
                    {
                        SITE: '顺德水道1',
                        LON: 113.28454,
                        LAT: 22.888338
                    },
                    {
                        SITE: '顺德水道2',
                        LON: 113.29072,
                        LAT: 22.883119
                    },
                    {
                        SITE: '顺德水道3',
                        LON: 113.297758,
                        LAT: 22.878849
                    }
                ];
                this.branchMakers = [
                    {
                        SITE: '紫坭河1',
                        LON: 113.305483,
                        LAT: 22.893557
                    },
                    {
                        SITE: '紫坭河2',
                        LON: 113.317842,
                        LAT: 22.889524
                    },
                    {
                        SITE: '紫坭河3',
                        LON: 113.324108,
                        LAT: 22.886756
                    }
                ]
            }
        },
        mounted () {
            this.getMonitorNodeData();
            this.getPollutionSourceData();
            this.getContaminantData();
            let that = this;
            setTimeout(() => {
                that.sourceMap = new AMap.Map('sourceMap', {
                    zoom: 10,
                    center: [113.554177, 23.088718],
                    // showLabel: false,
                    viewMode: '3D',
                    mapStyle: 'amap://styles/dark'
                });
            }, 1000)
        },
        destroyed () {
            clearInterval(this.timer);
            this.timer = ''
        }
    }
</script>
<style scoped>
    .conMain{
        position:relative;
        background-color:#2a2a2a;
    }
    .cardTitle{
        color:#fff;
        font-size:15px
    }
    .amap-marker-content{
        color:red;
    }
    #map {
        width: 100%;
        height: 500px;
        margin: 0;
        padding: 0;
    }
</style>
<style lang="less" scoped>
.compute{
    position:absolute;
    top:35%;
    left:35%;
    width:400px;
    background-color:rgba(255,255,255,0.1);
    box-shadow: inset 0 0 10px #0a54ea;
    border-radius: 5px;
    text-align:center
}
.compute p{
    text-align:center;
    font-size:18px;
    color:#fff
}
:deep(.ivu-progress-text){
    color:#fff !important
}
@keyframes icon {
    0% {
        opacity: 0.8;
        transform: translate(0,0)
    }
    50% {
        opacity: 1;
        transform: translate(5px,20px)
    }
    100% {
        opacity: 0.8;
        transform: translate(0,0)
    }
}
.siteicon{
    width: 120px;
    height: 120px;
    text-align: center;
    margin: 10px auto;
    animation:  icon 3s linear infinite
}
.kp{
    margin:10px 20px;
    border-radius: 5px;
}
.kpDiv{
    padding:20px;
}
.kpName{
    color:#fff
}
:deep(.ivu-table){
    background: transparent !important;
    color:#fff !important
}
:deep(.ivu-table th){
    background: transparent !important;
}
:deep(.ivu-table td){
    background: transparent !important;
}
:deep(.ivu-input){
        outline: none !important;
        background: transparent !important;
        border: none !important;
        outline: medium !important;
        border-bottom: 1px solid #fff !important;
        border-radius:0;
        &::-webkit-input-placeholder {
            color: #fff !important;
        }
    }
:deep(.ivu-input:focus){
    outline: none;
    border: none;
}
:deep(.ivu-select-selection){
    border: none !important;
    background: transparent !important;
    border-bottom: 1px solid #fff !important;
    border-radius: 0px !important;
    color:#fff !important
}
:deep(.amap-marker-content){
    color:#fff
}
</style>
