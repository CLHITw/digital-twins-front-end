<template>
    <div class="conMain">
        <Row :gutter="16">
            <Col span="10" class="kp">
                <Row :gutter="16">
                    <Col span="12">
                        <div class="kpDiv">
                            <p class="cardTitle">
                                <Icon type="ios-apps"></Icon>
                                观测点
                            </p>
                            <Select v-model="monitor_node_arr" multiple @on-change="riverData()">
                                <Option v-for="(item,index) in monitorNodeData" :value="item.id" :key="index">{{ item.name }}</Option>
                            </Select>
                        </div>
                    </Col>
                    <Col span="12">
                        <div class="kpDiv">
                            <p class="cardTitle">
                                <Icon type="ios-bonfire"></Icon>
                                污染源
                            </p>
                            <Select v-model="pollution_source_arr" multiple>
                                <Option v-for="(item,index) in pollutionSourceData" :value="item.id" :key="index">{{ item.name }}</Option>
                            </Select>
                        </div>
                    </Col>
                    <Col span="12">
                        <div class="kpDiv">
                            <p class="cardTitle">
                                <Icon type="ios-flame"></Icon>
                                污染物
                            </p>
                            <p class="kpName">
                                污染物：
                                <Select v-model="contaminant_id" style="width:250px">
                                    <Option v-for="(item,index) in contaminantData" :value="item.id" :key="index">{{ item.name }}</Option>
                                </Select>
                            </p>
                            <p style="margin-top:10px"><span class="kpName">时间段：</span>&nbsp;<DatePicker style="width:250px" type="datetimerange" placeholder="请选择时间段" @on-change="selectTime"></DatePicker></p>
                        </div>
                    </Col>
                    <Col span="12">
                        <div class="kpDiv">
                            <p class="cardTitle">
                                <Icon type="ios-cloud"></Icon>
                                配置
                            </p>
                            <p class="kpName">时间步长：<Input disabled v-model="time_step" type="number" style="width:80px"/>&nbsp;&nbsp;网络步长：<Input disabled type="number" v-model="mesh_step" style="width:80px"/></p>
                            <p class="kpName" style="margin-top:10px">回溯时长：<Input disabled type="number" v-model="time_tracking" style="width:80px"/>&nbsp;&nbsp;降解系数：<Input disabled v-model="k_pollutant_degradation" style="width:80px"/></p>
                        </div>
                    </Col>
                    <Col span="12">
                        <div class="kpDiv">
                            <p class="cardTitle">
                                <Icon type="ios-cube"></Icon>
                                主河道
                            </p>
                            <span v-for="(item,index) in mainMakers" :key="index">{{item.SITE}}，</span>
                        </div>
                    </Col>
                    <Col span="12">
                        <div class="kpDiv">
                            <p slot="title" class="cardTitle">
                                <Icon type="md-git-branch"></Icon>
                                支流
                            </p>
                            <span v-for="(item,index) in branchMakers" :key="index">{{item.SITE}}，</span>
                        </div>
                    </Col>
                    <Col span="24">
                        <p style="text-align:center">
                            <Button style="margin-top:20px" type="primary" @click="sourceCalculateAction()">开始溯源</Button>
                        </p>
                    </Col>
                    <Col span="24" style="margin-top:20px">
                        <Table max-height="460" :columns="columns" border :data="historyData"></Table>
                    </Col>
                </Row>
            </Col>
            <Col span="13" style="padding:5px">
                <!-- <dv-border-box-10 :color="['#0a54ea', '#fff']"> -->
                    <div style="padding:10px;box-shadow: inset 0 0 10px #0a54ea;border-radius:5px;position:relative">
                        <div style="display:flex;align-items: center;color:#fff;position:absolute;top:20px;left:20px;z-index:99">
                            <Select style="width:200px;margin-right:20px" @on-change="selectKeyAction">
                                <Option v-for="(item,index) in selectKey" :value="item.value" :key="index">{{ item.label }}</Option>
                            </Select>
                            <Button style="margin-right:20px" type="primary" @click="heatPlay()">{{playTitle}}</Button>
                            <span>{{playIndex}}</span>
                        </div>
                        <div :style="{height:mapHeight}">
                            <el-amap :zoom="zoom" :center="center" mapStyle="dark">
                                <el-amap-marker v-for="(marker, index) in markers" :key="index" :content="marker.content" :position="marker.position"></el-amap-marker>
                            </el-amap>
                        </div>
                        <div class="playCharts">
                            <div ref="timeBar" v-height="300" style="width:50%;margin-top:100px"></div>
                            <div ref="time3D" v-height="400" style="width:50%"></div>
                        </div>
                    </div>
                <!-- </dv-border-box-10> -->
            </Col>
        </Row>
        <div class="compute" v-if="showCompute">
            <dv-border-box-8 :color="['#0a54ea', '#fff']">
                <div style="padding:20px">
                    <div class="siteicon">
                        <img src="@/assets/images/river.png" style="width:100px"/>
                    </div>
                    <p>{{comTitle}}......{{percent}}%</p>
                    <Progress :percent="percent" status="active" hide-info/>
                </div>
            </dv-border-box-8>
        </div>
    </div>
</template>
<script>
    import echarts from 'echarts';
    import 'echarts-gl';
    import { mapState } from 'vuex';
    import { monitorNode, sourceHistory, pollutionSource, contaminant, sourceCalculate } from '@api/sourceCalculate';
    export default {
        name: 'contaminant',
        data () {
            return {
                showCompute: false,
                percent: 0,
                monitorNodeData: [],
                pollutionSourceData: [],
                contaminantData: [],
                monitor_node_arr: [],
                pollution_source_arr: [],
                monitorData: [],
                contaminant_id: '',
                start_time: '',
                end_time: '',
                mesh_step: 300,
                time_step: 200,
                time_tracking: 1800,
                k_pollutant_degradation: '0.000006',
                sourceMap: '',
                sourceData: {},
                selectKey: [],
                playData: [],
                timer: '',
                playIndex: 0,
                mapHeight: document.documentElement.clientHeight - 94 + 'px',
                playTitle: '播放',
                comTitle: '',
                branchMakers: [],
                mainMakers: [],
                historyData: [],
                columns: [
                    {
                        title: '观测点',
                        key: 'monitor_node_name'
                    },
                    {
                        title: '污染物',
                        key: 'contaminant_name'
                    },
                    {
                        title: '浓度',
                        key: 'count'
                    }
                ],
                zoom: 11,
                center: [113.554177, 23.088718],
                markers: [],
                playData3D: []
            }
        },
        computed: {
            ...mapState('admin/layout', [
                'isMobile'
            ])
        },
        methods: {
            // 监测点
            async getMonitorNodeData () {
                let res = await monitorNode();
                if (res.errno === 0) {
                    this.monitorNodeData = res.data
                } else {
                    this.$Message['error']({
                        content: res.errmsg,
                        duration: 3
                    });
                };
            },
            // 污染源
            async getPollutionSourceData () {
                let res = await pollutionSource();
                if (res.errno === 0) {
                    this.pollutionSourceData = res.data
                } else {
                    this.$Message['error']({
                        content: res.errmsg,
                        duration: 3
                    });
                };
            },
            // 污染物
            async getContaminantData () {
                let res = await contaminant();
                if (res.errno === 0) {
                    this.contaminantData = res.data
                } else {
                    this.$Message['error']({
                        content: res.errmsg,
                        duration: 3
                    });
                };
            },
            async selectTime (e) {
                this.start_time = e[0];
                this.end_time = e[1];
                this.time_tracking = parseInt(new Date(e[1]) - new Date(e[0])) / 1000
                let params = {
                    monitor_node_arr: this.monitor_node_arr,
                    contaminant_id: this.contaminant_id,
                    start_time: this.start_time,
                    end_time: this.end_time
                }
                let res = await sourceHistory(params);
                if (res.errno === 0) {
                    this.historyData = res.data;
                } else {
                    this.$Message['error']({
                        content: res.errmsg,
                        duration: 3
                    });
                };
            },
            sourceCalculateAction () {
                if (this.monitor_node_arr.length === 0) {
                    this.$Message['warning']({
                        content: '监测点不能为空',
                        duration: 3
                    });
                    return;
                }
                if (this.pollution_source_arr.length === 0) {
                    this.$Message['warning']({
                        content: '污染源不能为空',
                        duration: 3
                    });
                    return;
                }
                if (!this.contaminant_id) {
                    this.$Message['warning']({
                        content: '污染物不能为空',
                        duration: 3
                    });
                    return;
                }
                if (!this.start_time || !this.end_time) {
                    this.$Message['warning']({
                        content: '时间段不能为空',
                        duration: 3
                    });
                    return;
                }
                if (this.mainMakers.length === 0) {
                    this.$Message['warning']({
                        content: '主流标记点不能为空',
                        duration: 3
                    });
                    return;
                }
                if (this.branchMakers.length === 0) {
                    this.$Message['warning']({
                        content: '支流标记点不能为空',
                        duration: 3
                    });
                    return;
                }
                if (this.historyData.length === 0) {
                    this.$Message['warning']({
                        content: '观测点监测数据为空',
                        duration: 3
                    });
                    return;
                }
                this.percent = 0
                this.comTitle = '上传数据'
                this.showCompute = true
                let that = this
                setTimeout(async () => {
                    that.comTitle = '上传数据'
                    that.percent = Math.floor(Math.random() * 10)
                }, 1000)
                setTimeout(async () => {
                    that.comTitle = '分析整理数据'
                    that.percent = Math.floor(Math.random() * 10 + 30)
                }, 3000)
                setTimeout(async () => {
                    that.comTitle = '数据导入算法模型'
                    that.percent = Math.floor(Math.random() * 10 + 50)
                }, 5000)
                setTimeout(async () => {
                    that.comTitle = '算法模型计算'
                    that.percent = Math.floor(Math.random() * 10 + 80)
                    that.getSourceCalculateData();
                }, 6000)
                setTimeout(async () => {
                    that.comTitle = '溯源完成'
                    that.percent = 100
                }, 7000)
            },
            // 监测数据
            async getSourceCalculateData () {
                let params = {
                    monitor_node_arr: this.monitor_node_arr,
                    contaminant_id: this.contaminant_id,
                    start_time: this.start_time,
                    end_time: this.end_time,
                    sources_pollution_arr: this.pollution_source_arr,
                    main_river: this.mainMakers,
                    tributary_river: this.branchMakers,
                    other_params: {
                        mesh_step: parseInt(this.mesh_step),
                        time_step: parseInt(this.time_step),
                        time_tracking: parseInt(this.time_tracking),
                        k_pollutant_degradation: this.k_pollutant_degradation
                    }
                }
                let res = await sourceCalculate(params);
                this.showCompute = false
                if (res.errno === 0) {
                    this.sourceData = res.data;
                    let data = res.data;
                    this.selectKey = [];
                    let selectKey = Object.keys(data)
                    for (var i in selectKey) {
                        let name = '';
                        if (selectKey[i] === 'main river') {
                            name = '主河道'
                        } else {
                            name = '支流'
                        }
                        let info = {
                            value: name,
                            label: name
                        }
                        this.selectKey.push(info)
                    }
                } else {
                    this.$Message['error']({
                        content: res.errmsg,
                        duration: 3
                    });
                };
            },
            selectKeyAction (e) {
                let ca = true
                if (e === '主河道') {
                    e = 'main river'
                } else {
                    e = 'tributary river'
                    ca = false
                }
                this.playData = [];
                if (this.timer) {
                    clearInterval(this.timer);
                    this.timer = '';
                }
                this.playIndex = 0;
                this.playTitle = '播放'
                this.markers = [];
                let data = this.sourceData[e];
                let time = data.time
                let concentration = data.concentration;
                let location = data.location;
                for (var i in time) {
                    let info = {
                        time: time[i],
                        data: []
                    }
                    for (var j in concentration[i]) {
                        let a = {
                            count: concentration[i][j],
                            lat: location[i][j][1],
                            lng: location[i][j][0],
                            ca: ca
                        };
                        info.data.push(a);
                        let b = [j, time[i], concentration[i][j], location[i][j][0], location[i][j][1]]
                        this.playData3D.push(b)
                    };
                    this.playData.push(info)
                }
                this.zoom = 14;
                this.center = [this.playData[0].data[0].lng + 0.04, this.playData[0].data[0].lat - 0.02];
            },
            heatPlay () {
                let that = this
                var myChart3D = echarts.init(this.$refs.time3D);
                let option3D = {
                    tooltip: {
                        formatter: function (value) {
                            return '坐标：' + value.data[3] + ',' + value.data[4] + '<br />' + '时间序号：' + value.data[1] + '<br />' + '浓度：' + value.data[2];
                        }
                    },
                    backgroundColor: 'none',
                    visualMap: {
                        show: false,
                        dimension: 2,
                        inRange: {
                            color: ['#2d8cf0']
                        }
                    },
                    xAxis3D: {
                        type: 'value',
                        axisLabel: {
                            textStyle: {
                                color: '#fff'
                            }
                        },
                        name: '坐标',
                        nameTextStyle: {
                            color: '#fff'
                        }
                    },
                    yAxis3D: {
                        type: 'value',
                        axisLabel: {
                            textStyle: {
                                color: '#fff'
                            }
                        },
                        name: '时间序号',
                        nameTextStyle: {
                            color: '#fff'
                        }
                    },
                    zAxis3D: {
                        type: 'value',
                        axisLabel: {
                            textStyle: {
                                color: '#fff'
                            }
                        },
                        name: '浓度',
                        nameTextStyle: {
                            color: '#fff'
                        }
                    },
                    grid3D: {
                        show: false
                    },
                    series: [
                        {
                            type: 'surface',
                            data: this.playData3D
                        }
                    ]
                };
                myChart3D.setOption(option3D)
                var myChart = echarts.init(this.$refs.timeBar);
                if (this.playTitle === '播放') {
                    that.playTitle = '暂停'
                    this.timer = setInterval(() => {
                        if (that.playIndex + 1 > that.playData.length) {
                            clearInterval(that.timer);
                            that.timer = '';
                            that.playTitle = '播放'
                            that.playIndex = 0
                            return
                        }
                        let data = that.playData[that.playIndex].data
                        this.markers = []
                        let datax = [];
                        let datay = []
                        for (var i in data) {
                            datax.push(i)
                            datay.push(data[i].count);
                            if (data[i].count > 0) {
                                let position = [];
                                if (data[i].ca) {
                                    position = [data[i].lng, data[i].lat - 0.0055]
                                } else {
                                    position = [data[i].lng + 0.005, data[i].lat - 0.0035]
                                }
                                let marker = {
                                    position: position,
                                    content: `<div class="flu"><span class="flunormal"></span></div>`
                                };
                                this.markers.push(marker)
                            }
                        }
                        let option = {
                            tooltip: {
                                trigger: 'item',
                                formatter: '{b} : {c}'
                            },
                            xAxis: {
                                type: 'category',
                                axisLine: {
                                    'show': false
                                },
                                axisTick: {
                                    'show': false
                                },
                                axisLabel: {
                                    textStyle: {
                                        color: '#fff'
                                    }
                                },
                                data: datax
                            },
                            yAxis: {
                                axisLabel: {
                                    textStyle: {
                                        color: '#fff'
                                    }
                                },
                                dispaly: 'none',
                                'axisLine': {
                                    'show': false
                                },
                                'axisTick': {
                                    'show': false
                                },
                                'splitLine': {
                                    'show': true
                                },
                                'show': true
                            },
                            series: [
                                {
                                    data: datay,
                                    type: 'bar',
                                    color: ['#409eff']
                                }
                            ]
                        };
                        myChart.setOption(option)
                        that.playIndex++
                    }, 300);
                } else {
                    clearInterval(that.timer);
                    that.timer = '';
                    that.playTitle = '播放'
                }
            },
            riverData () {
                this.mainMakers = [
                    {
                        SITE: '沙湾水道1',
                        LON: 113.28454,
                        LAT: 22.888338
                    },
                    {
                        SITE: '沙湾水道2',
                        LON: 113.29072,
                        LAT: 22.883119
                    },
                    {
                        SITE: '沙湾水道3',
                        LON: 113.297758,
                        LAT: 22.878849
                    }
                ];
                this.branchMakers = [
                    {
                        SITE: '紫坭河1',
                        LON: 113.305483,
                        LAT: 22.893557
                    },
                    {
                        SITE: '紫坭河2',
                        LON: 113.317842,
                        LAT: 22.889524
                    },
                    {
                        SITE: '紫坭河3',
                        LON: 113.324108,
                        LAT: 22.886756
                    }
                ]
            }
        },
        mounted () {
            this.getMonitorNodeData();
            this.getPollutionSourceData();
            this.getContaminantData();
        },
        destroyed () {
            clearInterval(this.timer);
            this.timer = ''
        }
    }
</script>
<style scoped>
    .conMain{
        position:relative;
        background-color:#2a2a2a;
    }
    .cardTitle{
        color:#fff;
        font-size:15px;
        margin-bottom:5px
    }
    .amap-marker-content{
        color:red;
    }
    #map {
        width: 100%;
        height: 500px;
        margin: 0;
        padding: 0;
    }
</style>
<style>
.flu{
    text-align:center;
    margin: 0 auto;
    width: 35px;
    height: 35px;
    background-color: #e03906;
    box-shadow:0px 0px 15px #e03906;
    border-radius: 50%;
    -webkit-animation-name: 'fluBreath';/*动画属性名，也就是我们前面keyframes定义的动画名*/
    -webkit-animation-duration: 1s;/*动画持续时间*/
    -webkit-animation-timing-function: ease; /*动画频率，和transition-timing-function是一样的*/
    -webkit-animation-delay: 0s;/*动画延迟时间*/
    -webkit-animation-iteration-count: infinite;/*定义循环资料，infinite为无限次*/
    -webkit-animation-direction: alternate;/*定义动画方式*/
}
@keyframes fluBreath{
    0% {margin-left: 0;margin-top: 0;width:35px;height:35px;box-shadow:0px 0px 15px #e03906;}
    100% {margin-left: 5px;margin-top: 5px;width:25px;height:25px;box-shadow:0px 0px 10px #e03906;}
}
.flunormal span{
    line-height:30px;
    font-size:13px;
    -webkit-animation-name: 'breathSpan';
    -webkit-animation-duration: 1s;
    -webkit-animation-timing-function: ease;
    -webkit-animation-delay: 0s;
    -webkit-animation-iteration-count: infinite;
    -webkit-animation-direction: alternate;
}
@keyframes breathSpan{
    0% {line-height:30px}
    100% {line-height:20px}
}
</style>
<style lang="less" scoped>
.compute{
    position:absolute;
    top:35%;
    left:35%;
    width:400px;
    background-color:rgba(255,255,255,0.1);
    box-shadow: inset 0 0 10px #0a54ea;
    border-radius: 5px;
    text-align:center
}
.compute p{
    text-align:center;
    font-size:18px;
    color:#fff
}
:deep(.ivu-progress-text){
    color:#fff !important
}
@keyframes icon {
    0% {
        opacity: 0.8;
        transform: translate(0,0)
    }
    50% {
        opacity: 1;
        transform: translate(5px,20px)
    }
    100% {
        opacity: 0.8;
        transform: translate(0,0)
    }
}
.siteicon{
    width: 120px;
    height: 120px;
    text-align: center;
    margin: 10px auto;
    animation:  icon 3s linear infinite
}
.kp{
    margin:10px 20px;
    border-radius: 5px;
}
.kpDiv{
    margin-top:20px;
    padding:10px;
}
.kpDiv span{
    color:#fff
}
.kpName{
    color:#fff
}
:deep(.ivu-table){
    background: transparent !important;
    color:#fff !important
}
:deep(.ivu-table th){
    background: transparent !important;
}
:deep(.ivu-table td){
    background: transparent !important;
}
:deep(.ivu-input){
        outline: none !important;
        background: transparent !important;
        border: none !important;
        outline: medium !important;
        border-bottom: 1px solid #fff !important;
        border-radius:0;
        &::-webkit-input-placeholder {
            color: #fff !important;
        }
    }
:deep(.ivu-input:focus){
    outline: none;
    border: none;
}
:deep(.ivu-select-selection){
    border: none !important;
    background: transparent !important;
    border-bottom: 1px solid #fff !important;
    border-radius: 0px !important;
    color:#fff !important
}
:deep(.amap-marker-content){
    color:#fff
}
:deep(.ivu-tag){
    border: none !important;
    background: transparent !important;
    color:#fff !important
}
:deep(.ivu-tag-text){
    color:#fff !important
}
.playCharts{
    position:absolute;
    bottom:0px;
    left:0px;
    z-index:99;
    width:98%;
    margin:1%;
    padding:0px 10px;
    // background:rgba(255,255,255,0.2);
    display: flex;
    border-radius: 5px;
}
</style>
