<template>
    <div class="mainMap">
        <div :style="{height:mapHeight}">
            <el-amap :zoom="zoom" :center="center" mapStyle="dark">
                <el-amap-marker v-for="(marker, index) in markers" :key="index" :content="marker.content" :position="marker.position" :vid="index"></el-amap-marker>
            </el-amap>
        </div>
        <div class="find">
            <p>
                <Select style="width:320px" v-model="monitor_node_id" placeholder="请选择观测点">
                    <Option v-for="(item,index) in monitorNodeData" :value="item.id" :key="index">{{ item.name }}</Option>
                </Select>
            </p>
            <p><DatePicker style="width:320px" type="datetimerange" placeholder="请选择时间段" @on-change="selectTime"></DatePicker></p>
            <Button icon="ios-search" type="primary" @click="getList()">溯源</Button>
        </div>
        <div class="resList" v-if="data.length>0">
            <Table highlight-row  :columns="columnsList" border :data="data"  @on-current-change="selectRow"></Table>
        </div>
        <div class="res" v-if="resShow">
            <p>溯源结果：</p>
            <Table  :columns="columns" border :data="tableData"></Table>
            <p style="margin-top:5px" v-if="info.img">图片：</p>
            <img :src="info.img"/>
        </div>
        <div class="compute" v-if="showCompute">
            <dv-border-box-8 :color="['#0a54ea', '#fff']">
                <div style="padding:20px">
                    <div class="siteicon">
                        <img src="@/assets/images/river.png" style="width:100px"/>
                    </div>
                    <p>{{comTitle}}......{{percent}}%</p>
                    <Progress :percent="percent" status="active" hide-info/>
                </div>
            </dv-border-box-8>
        </div>
    </div>
</template>
<script>
    import { mapState } from 'vuex';
    import { monitorNode, sourceFluorescence } from '@api/sourceCalculate';
    export default {
        name: 'fluorescence_source',
        data () {
            return {
                data: [],
                zoom: 11,
                center: [113.554177, 23.088718],
                mapHeight: document.documentElement.clientHeight - 64 + 'px',
                monitorNodeData: [],
                monitor_node_id: '',
                start_time: '',
                end_time: '',
                markers: [],
                resShow: false,
                info: {},
                tableData: [],
                columnsList: [
                    {
                        title: '污染源',
                        key: 'source'
                    },
                    {
                        title: '时间',
                        key: 'time'
                    }
                ],
                columns: [
                    {
                        title: '名称',
                        key: 'name',
                        width: 100
                    },
                    {
                        title: '',
                        key: 'value'
                    }
                ],
                showCompute: false,
                percent: 0,
                comTitle: ''
            }
        },
        computed: {
            ...mapState('admin/layout', [
                'isMobile'
            ])
        },
        methods: {
            // 污染物
            async getmonitorNodeData () {
                let res = await monitorNode();
                if (res.errno === 0) {
                    this.monitorNodeData = res.data
                } else {
                    this.$Message['error']({
                        content: res.errmsg,
                        duration: 3
                    });
                };
            },
            selectTime (e) {
                this.start_time = e[0];
                this.end_time = e[1]
            },
            async getList () {
                let that = this;
                if (!this.monitor_node_id) {
                    this.$Message['error']({
                        content: '请选择监测点',
                        duration: 3
                    });
                    return;
                }
                if (!this.start_time || !this.end_time) {
                    this.$Message['error']({
                        content: '请选择时间',
                        duration: 3
                    });
                    return;
                };
                let param = {
                    monitor_node_id: this.monitor_node_id,
                    start_time: this.start_time,
                    end_time: this.end_time
                }
                let res1 = await sourceFluorescence(param);
                if (res1.errno === 0) {
                    let data = res1.data;
                    if (data.length === 0) {
                        this.$Message['warning']({
                            content: '溯源数据为空',
                            duration: 3
                        });
                        return
                    }
                } else {
                    this.$Message['error']({
                        content: res1.errmsg,
                        duration: 3
                    });
                    return;
                }
                this.showCompute = true;
                this.percent = 0
                this.comTitle = '上传数据'
                setTimeout(async () => {
                    that.comTitle = '上传数据'
                    that.percent = Math.floor(Math.random() * 10)
                }, 1000)
                setTimeout(async () => {
                    that.comTitle = '分析整理数据'
                    that.percent = Math.floor(Math.random() * 10 + 30)
                }, 3000)
                setTimeout(async () => {
                    that.comTitle = '数据导入算法模型'
                    that.percent = Math.floor(Math.random() * 10 + 50)
                }, 5000)
                setTimeout(async () => {
                    that.comTitle = '算法模型计算'
                    that.percent = Math.floor(Math.random() * 10 + 80)
                }, 6000)
                setTimeout(async () => {
                    that.comTitle = '溯源完成'
                    that.percent = 100
                }, 7000)
                setTimeout(async () => {
                    that.showCompute = false
                    let params = {
                        monitor_node_id: that.monitor_node_id,
                        start_time: that.start_time,
                        end_time: that.end_time
                    }
                    let res = await sourceFluorescence(params);
                    if (res.errno === 0) {
                        this.data = res.data;
                    } else {
                        that.$Message['error']({
                            content: res.errmsg,
                            duration: 3
                        });
                    };
                }, 9000)
            },
            selectRow (e) {
                console.log(e)
                this.tableData = [];
                this.resShow = false;
                this.markers = [];
                let that = this;
                let info = e;
                let content = `<div class="flu">
                                    <span class="flunormal"></span>
                                </div><span style='color:#fff'>` + info.source + `</span>`
                let marker = {
                    position: [info.longitude, info.latitude],
                    content: content
                };
                that.markers.push(marker);
                let content1 = `<img class="markerImg" src="http://52.81.152.99:8081/img/dw.gif"/><span style='color:#fff'>` + info.monitor_node_name + `</span>`
                let marker1 = {
                    position: [info.longitude, info.latitude],
                    content: content1
                };
                that.markers.push(marker1);
                that.zoom = 13;
                that.center = [info.longitude, info.latitude];
                that.resShow = true;
                that.info = info;
                this.tableData.push(
                    {
                        name: '监测点',
                        value: info.monitor_node_name
                    },
                    {
                        name: '样本',
                        value: info.sample_name
                    },
                    {
                        name: '相似度',
                        value: info.similarity + '%'
                    },
                    {
                        name: '超标',
                        value: info.excess
                    },
                    {
                        name: '荧光峰1',
                        value: info.peak1 + '荧光强度：' + info.intensity1
                    },
                    {
                        name: '荧光峰2',
                        value: info.peak2 + '荧光强度：' + info.intensity2
                    },
                    {
                        name: '荧光峰3',
                        value: info.peak3 + '荧光强度：' + info.intensity3
                    }
                )
            }
        },
        mounted () {
            this.getmonitorNodeData();
        }
    }
</script>
<style lang="less">
    .markerImg{
        width:40px;
        height:40px
    }
    .mainMap{
        position:relative
    }
    .find{
        position:absolute;
        top:20px;
        left:20px;
        display:flex;
        align-items:center
    }
    .find p{
        margin-right:10px
    }
    .resList{
        position:absolute;
        top:70px;
        left:20px;
        width:350px;
        background-color:rgba(255,255,255,0.1);
        border-radius: 5px;
    }
    .res{
        position:absolute;
        top:20px;
        right:20px;
        width:400px;
        background-color:rgba(255,255,255,0.1);
        box-shadow: inset 0 0 10px #0a54ea;
        padding:10px;
        border-radius: 5px;
    }
    .res p{
        color:#fff;
        font-size:15px;
        margin-bottom:5px
    }
    .res img{
        width:100%;
    }
    .flu{
        text-align:center;
        margin: 0 auto;
        width: 35px;
        height: 35px;
        background-color: #e03906;
        box-shadow:0px 0px 15px #e03906;
        border-radius: 50%;
        -webkit-animation-name: 'fluBreath';/*动画属性名，也就是我们前面keyframes定义的动画名*/
        -webkit-animation-duration: 1s;/*动画持续时间*/
        -webkit-animation-timing-function: ease; /*动画频率，和transition-timing-function是一样的*/
        -webkit-animation-delay: 0s;/*动画延迟时间*/
        -webkit-animation-iteration-count: infinite;/*定义循环资料，infinite为无限次*/
        -webkit-animation-direction: alternate;/*定义动画方式*/
    }
    @keyframes fluBreath{
        0% {margin-left: 0;margin-top: 0;width:35px;height:35px;box-shadow:0px 0px 15px #e03906;}
        100% {margin-left: 5px;margin-top: 5px;width:25px;height:25px;box-shadow:0px 0px 10px #e03906;}
    }
    .flunormal span,
    .offLineDevice span,
    .alarmDevice span{
        line-height:30px;
        font-size:13px;
        -webkit-animation-name: 'breathSpan';
        -webkit-animation-duration: 1s;
        -webkit-animation-timing-function: ease;
        -webkit-animation-delay: 0s;
        -webkit-animation-iteration-count: infinite;
        -webkit-animation-direction: alternate;
    }
    @keyframes breathSpan{
        0% {line-height:30px}
        100% {line-height:20px}
    }
</style>
<style lang="less" scoped>
:deep(.ivu-table){
    background: transparent !important;
    color:#fff !important
}
:deep(.ivu-table th){
    background: transparent !important;
}
:deep(.ivu-table td){
    background: transparent !important;
}
.compute{
    position:absolute;
    top:35%;
    left:35%;
    width:400px;
    background-color:rgba(255,255,255,0.1);
    box-shadow: inset 0 0 10px #0a54ea;
    border-radius: 5px;
    text-align:center
}
.compute p{
    text-align:center;
    font-size:18px;
    color:#fff
}
:deep(.ivu-progress-text){
    color:#fff !important
}
@keyframes icon {
    0% {
        opacity: 0.8;
        transform: translate(0,0)
    }
    50% {
        opacity: 1;
        transform: translate(0px,10px)
    }
    100% {
        opacity: 0.8;
        transform: translate(0,0)
    }
}
.siteicon{
    width: 120px;
    height: 120px;
    text-align: center;
    margin: 10px auto;
    animation:  icon 2s linear infinite
}
:deep(.ivu-input){
        outline: none !important;
        background: transparent !important;
        border: none !important;
        outline: medium !important;
        color: #fff !important;
        border-bottom: 1px solid #fff !important;
        border-radius:0;
        &::-webkit-input-placeholder {
            color: #fff !important;
        }
    }
:deep(.ivu-input:focus){
    outline: none;
    border: none;
}
:deep(.ivu-select-selection){
    border: none !important;
    background: transparent !important;
    border-bottom: 1px solid #fff !important;
    border-radius: 0px !important;
    color:#fff !important
}
</style>
