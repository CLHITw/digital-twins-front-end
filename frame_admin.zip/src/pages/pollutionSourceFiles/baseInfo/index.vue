<template>
    <div>
        <Row :gutter="10">
            <Col span="18">
                <Card :bordered="false" dis-hover class="ivu-mt">
                    <div style="display:flex;align-items:center">
                        <p style="margin-right:20px">污染源名称：<Input  style="width:200px;" v-model="name" clearable/></p>
                        <Button style="margin-right:20px" icon="ios-search" type="primary" @click="getData()">搜索</Button>
                        <Button style="margin-right:20px" type="primary" icon="md-add" @click="handleOpenAdd">新建</Button>
                        <Upload  action="/" :before-upload="beforeUpload" :show-upload-list="false">
                            <Button type="primary" icon="ios-cloud-upload-outline">导入</Button>
                        </Upload>
                    </div>
                    <div class="ivu-inline-block ivu-fr">
                        <Dropdown trigger="click">
                            <Tooltip class="ivu-ml" content="列设置" placement="top">
                                <i-link>
                                    <Icon type="md-options" />
                                </i-link>
                            </Tooltip>
                            <DropdownMenu slot="list">
                                <div class="ivu-p-8">
                                    <Row>
                                        <Col span="12">列展示</Col>
                                        <Col span="12" class="ivu-text-right">
                                            <i-link link-color @click.native="handleResetColumn">重置</i-link>
                                        </Col>
                                    </Row>
                                </div>
                                <Divider size="small" class="ivu-mt-8 ivu-mb-8" />
                                <li class="ivu-dropdown-item" v-for="item in columns" :key="item.title"  @click="item.show = !item.show">
                                    <Checkbox v-model="item.show"></Checkbox>
                                    <span>{{ item.title }}</span>
                                </li>
                            </DropdownMenu>
                        </Dropdown>
                    </div>
                    <List item-layout="vertical" style="margin-top:30px">
                        <Table highlight-row :columns="tableColumns" border :data="data" :loading="loading" @on-current-change="selectRow">
                            <template slot-scope="{ row }" slot="dealwith">
                                <p>{{row.pollution_dealwith_facilities_name}}</p>
                                <p>{{row.pollution_dealwith_way_name}}</p>
                            </template>
                            <template slot-scope="{ row }" slot="action">
                                <Button type="primary" size="small" style="margin-right: 5px" @click="edit(row)">编辑</Button>
                                <Button type="error" size="small" @click="remove(row.id,row.name)">删除</Button>
                            </template>
                        </Table>
                        <div class="ivu-mt ivu-text-center" slot="footer">
                            <Page :current.sync="page" :total="count" :pageSize="pageSize" show-total show-elevator :simple="isMobile" @on-change="getData()"></Page>
                        </div>
                    </List>
                </Card>
            </Col>
            <Col  span="6">
                <Card :bordered="false" dis-hover>
                    <div v-if="detailTitle" style="display:flex;align-items:center;margin-bottom:10px">
                        <p style="font-size:16px;color:#333;margin-right:20px">{{detailTitle}}</p>
                        <Button type="primary" icon="md-add" @click="handleOpenEnterpriseAdd">添加</Button>
                    </div>
                    <Table  :columns="columns1" border :data="enterpriseData">
                        <template slot-scope="{ row }" slot="action">
                            <Button type="error" size="small" @click="removeEnterprise(row.id, row.enterprise_name)">删除</Button>
                        </template>
                    </Table>
                </Card>
            </Col>
        </Row>
        <Modal v-model="showModel" :title="title" :loading="creating" @on-ok="actionPollutionSource" :width="1000" :transfer="false">
            <Form ref="infoData" :model="infoData" :rules="addRules" :label-width="120">
                <Row :gutter="30">
                    <Col span="10">
                        <FormItem label="污染源名称：" prop="name">
                            <Input v-model="infoData.name" placeholder="请输入污染源名称" />
                        </FormItem>
                        <FormItem label="运营单位：" prop="unit">
                            <Input v-model="infoData.unit" placeholder="请输入运营单位" />
                        </FormItem>
                        <FormItem label="地址：" prop="address">
                            <Input v-model="infoData.address" placeholder="请输入地址" />
                        </FormItem>
                        <FormItem label="建成时间：" prop="build_time">
                            <DatePicker :value="infoData.build_time" type="month"  style="width: 100px" @on-change="selectMonth"/>
                        </FormItem>
                        <FormItem label="污水处理设施类型：" prop="pollution_dealwith_facilities_id">
                            <Select v-model="infoData.pollution_dealwith_facilities_id">
                                <Option v-for="item in dealwithFacilitiesData" v-bind:key="item.id" :value="item.id">{{item.name}}</Option>
                            </Select>
                        </FormItem>
                        <FormItem label="污水处理方法：" prop="pollution_dealwith_way_id">
                            <Select v-model="infoData.pollution_dealwith_way_id">
                                <Option v-for="item in dealwithWayData" v-bind:key="item.id" :value="item.id">{{item.name}}</Option>
                            </Select>
                        </FormItem>
                        <FormItem label="排水去向：" prop="whereabouts_type_id">
                            <Select v-model="infoData.whereabouts_type_id">
                                <Option v-for="item in whereaboutsTypeData" v-bind:key="item.id" :value="item.id">{{item.name}}</Option>
                            </Select>
                        </FormItem>
                        <FormItem label="受纳水体：" prop="accept_water_id">
                            <Select v-model="infoData.accept_water_id">
                                <Option v-for="item in acceptWaterData" v-bind:key="item.id" :value="item.id">{{item.name}}</Option>
                            </Select>
                        </FormItem>
                    </Col>
                    <Col span="14">
                        <FormItem label="位置坐标：" prop="coordinate">
                            经度：<Input style="width:150px" v-model="infoData.longitude" placeholder="请输入经度" />
                            纬度：<Input style="width:150px" v-model="infoData.latitude" placeholder="请输入纬度" />
                        </FormItem>
                        <div style="width:100%;height:390px;">
                            <el-amap :zoom="10" :center="center" :events="events" mapStyle="light">
                                <el-amap-marker v-if="markerPosition" :position="markerPosition" ></el-amap-marker>
                            </el-amap>
                        </div>
                    </Col>
                </Row>
            </Form>
        </Modal>
        <Modal v-model="addEnterpriseModel" title="添加关联企业" @on-ok="actionEnterprise" :transfer="false">
            <Select v-model="enterprise_id">
                <Option v-for="item in enterpriseSelectData" v-bind:key="item.id" :value="item.id">{{item.name}}</Option>
            </Select>
        </Modal>
    </div>
</template>
<script>
    import { mapState } from 'vuex';
    import { pollutionSourceList, pollutionSourceAdd, pollutionSourceDelete, pollutionSourceUpdate, pollutionSourceEnterpriseList, pollutionSourceEnterpriseAdd, pollutionSourceEnterpriseDelete, pollutionSourceImport, pollutionDealwithFacilities, pollutionDealwithWay } from '@api/pollutionSource';
    import { enterpriseSelect } from '@api/enterprise';
    import { acceptWater, whereaboutsType } from '@api/enterpriseOutlet';

    export default {
        name: 'pollution_source',
        data () {
            let self = this;
            return {
                dealwithFacilitiesData: [],
                dealwithWayData: [],
                whereaboutsTypeData: [],
                acceptWaterData: [],
                name: '',
                data: [],
                loading: false,
                page: 1,
                count: 0,
                pageSize: 10,
                columns: [
                    {
                        show: true,
                        title: '污染源名称',
                        key: 'name'
                    },
                    {
                        show: true,
                        title: '运营单位',
                        key: 'unit'
                    },
                    {
                        show: true,
                        title: '地址',
                        key: 'address'
                    },
                    {
                        show: true,
                        title: '建成时间',
                        key: 'build_time',
                        width: 100
                    },
                    {
                        show: true,
                        title: '污水处理',
                        slot: 'dealwith'
                    },
                    {
                        show: true,
                        title: '排水去向类型',
                        key: 'whereabouts_type_name'
                    },
                    {
                        show: true,
                        title: '受纳水体',
                        key: 'accept_water_name'
                    },
                    {
                        show: true,
                        title: '创建时间',
                        key: 'add_time',
                        width: 120
                    },
                    {
                        show: true,
                        title: '操作',
                        slot: 'action',
                        width: 130
                    }
                ],
                showModel: false,
                title: '',
                infoData: {
                    name: '',
                    unit: '',
                    address: '',
                    build_time: '',
                    pollution_dealwith_facilities_id: '',
                    pollution_dealwith_way_id: '',
                    whereabouts_type_id: '',
                    accept_water_id: '',
                    longitude: '',
                    latitude: ''
                },
                addRules: {
                    name: [
                        { required: true, message: '请输入污染源名称', trigger: 'blur' }
                    ]
                },
                creating: true,
                updateIndex: -1,
                updateId: '',
                center: [113.554177, 23.088718],
                events: {
                    click (e) {
                        let { lng, lat } = e.lnglat
                        self.markerPosition = [lng, lat]
                        self.infoData.longitude = lng;
                        self.infoData.latitude = lat
                    }
                },
                markerPosition: '',
                pollutionSourceId: '',
                enterpriseData: [],
                detailTitle: '',
                columns1: [
                    {
                        show: true,
                        title: '企业名称',
                        key: 'enterprise_name'
                    },
                    {
                        show: true,
                        title: '操作',
                        slot: 'action',
                        width: 80
                    }
                ],
                addEnterpriseModel: false,
                enterpriseSelectData: [],
                enterprise_id: ''
            }
        },
        computed: {
            ...mapState('admin/layout', [
                'isMobile'
            ]),
            // 动态设置列
            tableColumns () {
                const columns = [...this.columns];
                return columns.filter(item => item.show);
            }
        },
        methods: {
            // 企业
            async getEnterpriseSelectData () {
                let res = await enterpriseSelect();
                if (res.errno === 0) {
                    this.enterpriseSelectData = res.data
                } else {
                    this.$Message['error']({
                        content: res.errmsg,
                        duration: 3
                    });
                };
            },
            // 污水处理设施
            async getPollutionDealwithFacilitiesData () {
                let res = await pollutionDealwithFacilities();
                if (res.errno === 0) {
                    this.dealwithFacilitiesData = res.data
                } else {
                    this.$Message['error']({
                        content: res.errmsg,
                        duration: 3
                    });
                };
            },
            // 污水处理方法
            async getPollutionDealwithWayData () {
                let res = await pollutionDealwithWay();
                if (res.errno === 0) {
                    this.dealwithWayData = res.data
                } else {
                    this.$Message['error']({
                        content: res.errmsg,
                        duration: 3
                    });
                };
            },
            // 排水去向
            async getWhereaboutsTypeData () {
                let res = await whereaboutsType();
                if (res.errno === 0) {
                    this.whereaboutsTypeData = res.data
                } else {
                    this.$Message['error']({
                        content: res.errmsg,
                        duration: 3
                    });
                };
            },
            // 受纳水体
            async getAcceptWaterData () {
                let res = await acceptWater();
                if (res.errno === 0) {
                    this.acceptWaterData = res.data
                } else {
                    this.$Message['error']({
                        content: res.errmsg,
                        duration: 3
                    });
                };
            },
            // 列表
            async getData () {
                this.loading = true;
                let params = {
                    page: this.page,
                    name: this.name
                };
                let res = await pollutionSourceList(params);
                if (res.errno === 0) {
                    this.data = res.data.data;
                    this.count = res.data.count;
                    this.pageSize = res.data.pageSize;
                } else {
                    this.$Message['error']({
                        content: res.errmsg,
                        duration: 3
                    });
                };
                this.loading = false;
            },
            // 添加
            handleOpenAdd () {
                this.title = '添加污染源';
                this.updateIndex = -1;
                this.infoData = {
                    name: '',
                    unit: '',
                    address: '',
                    build_time: '',
                    pollution_dealwith_facilities_id: '',
                    pollution_dealwith_way_id: '',
                    whereabouts_type_id: '',
                    accept_water_id: '',
                    longitude: '',
                    latitude: ''
                };
                this.showModel = true;
            },
            // 编辑
            async edit (info) {
                this.title = '编辑污染源信息'
                this.updateIndex = info.id;
                this.updateId = info.id;
                this.infoData.name = info.name;
                this.infoData.unit = info.unit;
                this.infoData.address = info.address;
                this.infoData.build_time = info.build_time;
                this.infoData.pollution_dealwith_facilities_id = info.pollution_dealwith_facilities_id;
                this.infoData.pollution_dealwith_way_id = info.pollution_dealwith_way_id;
                this.infoData.whereabouts_type_id = info.whereabouts_type_id;
                this.infoData.accept_water_id = info.accept_water_id;
                this.infoData.longitude = info.longitude;
                this.infoData.latitude = info.latitude;
                if (info.longitude && info.latitude) {
                    this.center = [info.longitude, info.latitude]
                    this.markerPosition = [info.longitude, info.latitude]
                }
                this.showModel = true
            },
            async actionPollutionSource () {
                this.$refs.infoData.validate(async (valid) => {
                    if (valid) {
                        if (this.updateIndex < 0) {
                            // 新建
                            let res = await pollutionSourceAdd(this.infoData);
                            if (res.errno === 0) {
                                this.$Message.success(res.data);
                                this.showModel = false;
                                this.getData()
                            } else {
                                this.$Message.error(res.errmsg);
                            }
                        } else {
                            // 修改
                            let updateData = this.infoData;
                            updateData.id = this.updateId;
                            let res = await pollutionSourceUpdate(updateData);
                            if (res.errno === 0) {
                                this.$Message.success(res.data);
                                this.showModel = false;
                                this.getData()
                            } else {
                                this.$Message.error(res.errmsg);
                            }
                        }
                        this.creating = false;
                        this.$nextTick(() => {
                            this.creating = true;
                        });
                    } else {
                        this.creating = false;
                        this.$nextTick(() => {
                            this.creating = true;
                        });
                    }
                });
            },
            // 删除
            remove (id, name) {
                this.$Modal.confirm({
                    title: '删除污染源',
                    content: '确定删除污染源' + name + '吗？',
                    onOk: async () => {
                        let res = await pollutionSourceDelete({ id: id });
                        if (res.errno === 0) {
                            this.$Message.success(res.data);
                            this.getData()
                        } else {
                            this.$Message.error(res.errmsg);
                        }
                    }
                });
            },
            selectRow (e) {
                this.pollutionSourceId = e.id;
                this.detailTitle = e.name;
                this.getEnterpriseData();
            },
            async getEnterpriseData () {
                let params = {
                    pollution_source_id: this.pollutionSourceId
                };
                let res = await pollutionSourceEnterpriseList(params);
                if (res.errno === 0) {
                    this.enterpriseData = res.data
                } else {
                    this.$Message['error']({
                        content: res.errmsg,
                        duration: 3
                    });
                };
            },
            handleOpenEnterpriseAdd () {
                this.enterprise_id = ''
                this.addEnterpriseModel = true
            },
            async actionEnterprise () {
                if (!this.enterprise_id) {
                    this.$Message['error']({
                        content: '请选择企业',
                        duration: 3
                    });
                    this.addEnterpriseModel = true
                } else {
                    let params = {
                        enterprise_id: this.enterprise_id,
                        pollution_source_id: this.pollutionSourceId
                    }
                    let res = await pollutionSourceEnterpriseAdd(params);
                    if (res.errno === 0) {
                        this.$Message.success(res.data);
                        this.addEnterpriseModel = false;
                        this.getEnterpriseData()
                    } else {
                        this.$Message.error(res.errmsg);
                    }
                }
            },
            // 删除
            removeEnterprise (id, name) {
                this.$Modal.confirm({
                    title: '删除关联企业',
                    content: '确定删除关联企业' + name + '吗？',
                    onOk: async () => {
                        let res = await pollutionSourceEnterpriseDelete({ id: id });
                        if (res.errno === 0) {
                            this.$Message.success(res.data);
                            this.getEnterpriseData()
                        } else {
                            this.$Message.error(res.errmsg);
                        }
                    }
                });
            },
            beforeUpload (file) {
                let that = this;
                this.$Table.import({
                    type: 'xlsx',
                    file: file,
                    finish: (res) => {
                        let data = res.data;
                        that.import(data)
                    }
                });
                return false;
            },
            async import (data) {
                let res = await pollutionSourceImport({ data: data });
                if (res.errno === 0) {
                    let msg = '成功添加' + res.data.successCount + '条，失败' + res.data.failCount + '条'
                    this.$Message.success(msg);
                    this.getData()
                } else {
                    this.$Message.error(res.errmsg);
                }
            },
            selectMonth (e) {
                this.infoData.build_time = e
            },
            // 重置表格列设置
            handleResetColumn () {
                this.columns = this.columns.map(item => {
                    const newItem = item;
                    newItem.show = true;
                    return newItem;
                });
            }
        },
        mounted () {
            this.getData();
            this.getEnterpriseSelectData()
            this.getPollutionDealwithFacilitiesData()
            this.getPollutionDealwithWayData()
            this.getWhereaboutsTypeData()
            this.getAcceptWaterData()
        }
    }
</script>
