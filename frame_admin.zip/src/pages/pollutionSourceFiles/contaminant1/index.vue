<template>
    <div>
        <Card :bordered="false" dis-hover class="ivu-mt">
            <div style="display:flex;align-items:center">
                <p style="margin-right:20px">污染源名称：<Input  style="width:200px;" v-model="pollution_source_name" clearable/></p>
                <p style="margin-right:20px">污染物名称：<Input  style="width:200px;" v-model="contaminant_name" clearable/></p>
                <Button style="margin-right:20px" icon="ios-search" type="primary" @click="getData()">搜索</Button>
                <Button style="margin-right:20px" type="primary" icon="md-add" @click="handleOpenAdd">新建</Button>
                <Upload action="/" :before-upload="beforeUpload" :show-upload-list="false">
                    <Button type="primary" icon="ios-cloud-upload-outline">导入</Button>
                </Upload>
            </div>
            <div class="ivu-inline-block ivu-fr">
                <Dropdown trigger="click">
                    <Tooltip class="ivu-ml" content="列设置" placement="top">
                        <i-link>
                            <Icon type="md-options" />
                        </i-link>
                    </Tooltip>
                    <DropdownMenu slot="list">
                        <div class="ivu-p-8">
                            <Row>
                                <Col span="12">列展示</Col>
                                <Col span="12" class="ivu-text-right">
                                    <i-link link-color @click.native="handleResetColumn">重置</i-link>
                                </Col>
                            </Row>
                        </div>
                        <Divider size="small" class="ivu-mt-8 ivu-mb-8" />
                        <li class="ivu-dropdown-item" v-for="item in columns" :key="item.title"  @click="item.show = !item.show">
                            <Checkbox v-model="item.show"></Checkbox>
                            <span>{{ item.title }}</span>
                        </li>
                    </DropdownMenu>
                </Dropdown>
            </div>
            <List item-layout="vertical" style="margin-top:30px">
                <Table  :columns="tableColumns" border :data="data" :loading="loading">
                    <template slot-scope="{ row }" slot="time">
                        {{row.start_time}}~{{row.end_time}}
                    </template>
                    <template slot-scope="{ row }" slot="action">
                        <Button type="primary" size="small" style="margin-right: 5px" @click="edit(row)">编辑</Button>
                        <Button type="error" size="small" @click="remove(row.id,row.pollution_source_name, row.contaminant_name)">删除</Button>
                    </template>
                </Table>
                <div class="ivu-mt ivu-text-center" slot="footer">
                    <Page :current.sync="page" :total="count" :pageSize="pageSize" show-total show-elevator :simple="isMobile" @on-change="getData()"></Page>
                </div>
            </List>
        </Card>
        <Modal v-model="showModel" :title="title" :loading="creating" @on-ok="actionControl" :transfer="false">
            <Form ref="infoData" :model="infoData" :rules="addRules" :label-width="120">
                <FormItem label="污染源：" prop="pollution_source_id">
                    <Select v-model="infoData.pollution_source_id">
                        <Option v-for="item in pollutionSourceData" v-bind:key="item.id" :value="item.id">{{item.name}}</Option>
                    </Select>
                </FormItem>
                <FormItem label="污染物：" prop="contaminant_id">
                    <Select v-model="infoData.contaminant_id">
                        <Option v-for="item in contaminantData" v-bind:key="item.id" :value="item.id">{{item.name}}</Option>
                    </Select>
                </FormItem>
                <FormItem label="月份：" prop="month">
                    <Select v-model="infoData.month" style="width:100px">
                        <Option v-for="item in monthData" :value="item.value" :key="item.value">{{ item.value }}</Option>
                    </Select>
                </FormItem>
                <FormItem label="时间范围：" prop="time">
                    <TimePicker :value="infoData.time" type="timerange" placement="bottom-end" placeholder="请选择时间范围" style="width: 168px" @on-change="changeTime" />
                </FormItem>
                <FormItem label="指标值：" prop="count">
                    <Input v-model="infoData.count" placeholder="请输入指标值" style="width: 168px"/>
                </FormItem>
            </Form>
        </Modal>
    </div>
</template>
<script>
    import { mapState } from 'vuex';
    import { pollutionSourceContaminantList, pollutionSourceContaminantAdd, pollutionSourceContaminantDelete, pollutionSourceContaminantUpdate, contaminant, pollutionSourceContaminantImport } from '@api/pollutionSourceContaminant';
    import { pollutionSourceSelect } from '@api/pollutionSource';

    export default {
        name: 'pollutionSourceContaminant',
        data () {
            return {
                pollution_source_name: '',
                contaminant_name: '',
                pollutionSourceData: [],
                contaminantData: [],
                data: [],
                loading: false,
                page: 1,
                count: 0,
                pageSize: 10,
                columns: [
                    {
                        show: true,
                        title: '污染物',
                        key: 'contaminant_name'
                    },
                    {
                        show: true,
                        title: '污染源',
                        key: 'pollution_source_name'
                    },
                    {
                        show: true,
                        title: '月份',
                        key: 'month',
                        width: 180
                    },
                    {
                        show: true,
                        title: '时间范围',
                        slot: 'time',
                        width: 180
                    },
                    {
                        show: true,
                        title: '指标值',
                        key: 'count',
                        width: 180
                    },
                    {
                        show: true,
                        title: '创建时间',
                        key: 'add_time',
                        width: 180
                    },
                    {
                        show: true,
                        title: '操作',
                        slot: 'action',
                        width: 150
                    }
                ],
                showModel: false,
                title: '',
                infoData: {
                    type: 2,
                    pollution_source_id: '',
                    contaminant_id: '',
                    count: '',
                    month: '',
                    time: [],
                    start_time: '',
                    end_time: ''
                },
                addRules: {
                    contaminant_id: [
                        { required: true, message: '请选择污染物' }
                    ],
                    pollution_source_id: [
                        { required: true, message: '请选择污染源' }
                    ]
                },
                creating: true,
                updateIndex: -1,
                updateId: '',
                monthData: [
                    {
                        value: 1
                    }, {
                        value: 2
                    }, {
                        value: 3
                    }, {
                        value: 4
                    }, {
                        value: 5
                    }, {
                        value: 6
                    }, {
                        value: 7
                    }, {
                        value: 8
                    }, {
                        value: 9
                    }, {
                        value: 10
                    }, {
                        value: 11
                    }, {
                        value: 12
                    }
                ]
            }
        },
        computed: {
            ...mapState('admin/layout', [
                'isMobile'
            ]),
            // 动态设置列
            tableColumns () {
                const columns = [...this.columns];
                return columns.filter(item => item.show);
            }
        },
        methods: {
            // 污染源
            async getPollutionSourceData () {
                let res = await pollutionSourceSelect();
                if (res.errno === 0) {
                    this.pollutionSourceData = res.data
                } else {
                    this.$Message['error']({
                        content: res.errmsg,
                        duration: 3
                    });
                };
            },
            // 污染物
            async getContaminantData () {
                let res = await contaminant();
                if (res.errno === 0) {
                    this.contaminantData = res.data
                } else {
                    this.$Message['error']({
                        content: res.errmsg,
                        duration: 3
                    });
                };
            },
            // 列表
            async getData () {
                this.loading = true;
                let params = {
                    type: 2,
                    page: this.page,
                    pollution_source_name: this.pollution_source_name,
                    contaminant_name: this.contaminant_name
                };
                let res = await pollutionSourceContaminantList(params);
                if (res.errno === 0) {
                    this.data = res.data.data;
                    this.count = res.data.count;
                    this.pageSize = res.data.pageSize;
                } else {
                    this.$Message['error']({
                        content: res.errmsg,
                        duration: 3
                    });
                };
                this.loading = false;
            },
            // 添加
            handleOpenAdd () {
                this.title = '添加挥发性有机物指标';
                this.updateIndex = -1;
                this.infoData = {
                    type: 2,
                    pollution_source_id: '',
                    contaminant_id: '',
                    count: '',
                    month: '',
                    time: [],
                    start_time: '',
                    end_time: ''
                };
                this.showModel = true;
            },
            // 编辑
            async edit (info) {
                this.title = '编辑挥发性有机物指标信息'
                this.updateIndex = info.id;
                this.updateId = info.id;
                this.infoData.type = info.type;
                this.infoData.pollution_source_id = info.pollution_source_id;
                this.infoData.contaminant_id = info.contaminant_id;
                this.infoData.count = info.count;
                this.infoData.month = info.month;
                this.infoData.start_time = info.start_time;
                this.infoData.end_time = info.end_time;
                this.infoData.time = [info.start_time, info.end_time]
                this.showModel = true
            },
            async actionControl () {
                this.$refs.infoData.validate(async (valid) => {
                    if (valid) {
                        if (this.updateIndex < 0) {
                            // 新建
                            let res = await pollutionSourceContaminantAdd(this.infoData);
                            if (res.errno === 0) {
                                this.$Message.success(res.data);
                                this.showModel = false;
                                this.getData()
                            } else {
                                this.$Message.error(res.errmsg);
                            }
                        } else {
                            // 修改
                            let updateData = this.infoData;
                            updateData.id = this.updateId;
                            let res = await pollutionSourceContaminantUpdate(updateData);
                            if (res.errno === 0) {
                                this.$Message.success(res.data);
                                this.showModel = false;
                                this.getData()
                            } else {
                                this.$Message.error(res.errmsg);
                            }
                        }
                        this.creating = false;
                        this.$nextTick(() => {
                            this.creating = true;
                        });
                    } else {
                        this.creating = false;
                        this.$nextTick(() => {
                            this.creating = true;
                        });
                    }
                });
            },
            // 删除
            remove (id, pollutionSourceName, contaminantName) {
                this.$Modal.confirm({
                    title: '删除挥发性有机物指标',
                    content: '确定删除挥发性有机物指标：' + pollutionSourceName + '(' + contaminantName + ')' + '吗？',
                    onOk: async () => {
                        let res = await pollutionSourceContaminantDelete({ id: id });
                        if (res.errno === 0) {
                            this.$Message.success(res.data);
                            this.getData()
                        } else {
                            this.$Message.error(res.errmsg);
                        }
                    }
                });
            },
            changeTime (e) {
                this.infoData.time = e;
                this.infoData.start_time = e[0];
                this.infoData.end_time = e[1]
            },
            beforeUpload (file) {
                let that = this;
                this.$Table.import({
                    type: 'xlsx',
                    file: file,
                    finish: (res) => {
                        let data = res.data;
                        that.import(data)
                    }
                });
                return false;
            },
            async import (data) {
                let res = await pollutionSourceContaminantImport({ data: data });
                if (res.errno === 0) {
                    let msg = '成功添加' + res.data.successCount + '条，失败' + res.data.failCount + '条'
                    this.$Message.success(msg);
                    this.getData()
                } else {
                    this.$Message.error(res.errmsg);
                }
            },
            // 重置表格列设置
            handleResetColumn () {
                this.columns = this.columns.map(item => {
                    const newItem = item;
                    newItem.show = true;
                    return newItem;
                });
            }
        },
        mounted () {
            this.getData();
            this.getContaminantData();
            this.getPollutionSourceData();
        }
    }
</script>
