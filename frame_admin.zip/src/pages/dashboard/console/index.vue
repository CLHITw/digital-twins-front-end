<template>
    <div class="mapContent" :style='{height:pageHight}'>
        <el-amap :zoom="zoom" :center="center" mapStyle="dark">
            <el-amap-marker v-for="(marker, index) in markers" :key="index" :content="marker.content" :position="marker.position" :events="marker.events" :vid="index"></el-amap-marker>
            <el-amap-info-window
                v-if="window"
                :position="window.position"
                :visible="window.visible"
                :content="window.content"
                :offset="window.offset"
                :close-when-click-map="true"
                :is-custom="true"
            >
                <div id="info-window">
                    <p>
                        <span v-if="window.type==1">企业：</span>
                        <span v-else-if="window.type==2">污染源：</span>
                        <span v-else>监测点：</span>
                        {{ window.name }}
                    </p>
                    <p>
                        <span>地址：</span>
                        {{ window.address }}
                    </p>
                </div>
            </el-amap-info-window>
        </el-amap>
        <div class="infoCount">
            <div class="infoCountItem">
                <img src="@/assets/images/dw.gif"/>
                企业：<span>{{info.enterpriseCount}}</span>
            </div>
            <div class="infoCountItem">
                <div class="pollutionSource"></div>
                污染源：<span>{{info.pollutionSourceCount}}</span>
            </div>
            <div class="infoCountItem">
                <div class="monitor"></div>
                监测点：<span>{{info.monitorNodeCount}}</span>
            </div>
        </div>
        <div class="search">
            <p><Input placeholder="请输入企业名称" v-model="enterprise_name" clearable/></p>
            <p><Input placeholder="请输入污染源名称" v-model="pollution_source_name" clearable/></p>
            <p><Input placeholder="请输入监测点名称" v-model="monitor_node_name" clearable/></p>
            <Icon type="ios-search" @click="getList()" style="color:#fff;font-size:20px"/>
        </div>
        <div class="enterpriseGun" v-if="config1.data.length>0">
            <p class="guName">企业</p>
            <dv-scroll-board :config="config1" style="height:200px" @click="showMapmaker"/>
        </div>
        <div class="monitorGun"  v-if="config2.data.length>0">
            <p class="guName">污染源</p>
            <dv-scroll-board :config="config2" style="height:200px" @click="showMapmaker"/>
        </div>
        <div class="pollutionGun"  v-if="config3.data.length>0">
            <p class="guName">监测点</p>
            <dv-scroll-board :config="config3" style="height:200px" @click="showMapmaker"/>
        </div>
        <div class="zs">
            <dv-decoration-12 :color="['#0a54ea', '#e8eaec']" style="width:150px;height:150px;" />
        </div>
    </div>
</template>
<script>
    import { baseinfoCount, list } from '@api/home';
    export default {
        name: 'dashboard-console',
        data () {
            return {
                data: [],
                enterprise_name: '',
                pollution_source_name: '',
                monitor_node_name: '',
                zoom: 11,
                center: [113.554177, 23.088718],
                pageHight: document.documentElement.clientHeight - 64 + 'px',
                info: {},
                markers: [],
                windows: [],
                window: '',
                config1: {
                    columnWidth: [350],
                    oddRowBGC: '',
                    evenRowBGC: '',
                    data: []
                },
                config2: {
                    columnWidth: [350],
                    oddRowBGC: '',
                    evenRowBGC: '',
                    data: []
                },
                config3: {
                    columnWidth: [350],
                    oddRowBGC: '',
                    evenRowBGC: '',
                    data: []
                }
            }
        },
        mounted () {
            window.onresize = () => {
                return (() => {
                    this.$nextTick(() => {
                        this.pageHight = document.documentElement.clientHeight - 64 + 'px'
                    })
                })()
            };
            this.getBaseinfoCount();
        },
        methods: {
            async getBaseinfoCount () {
                let res = await baseinfoCount();
                if (res.errno === 0) {
                    this.info = res.data;
                    this.getList()
                } else {
                    this.$Message['error']({
                        content: res.errmsg,
                        duration: 3
                    });
                };
            },
            async getList () {
                this.markers = []
                this.windows = []
                let params = {
                    enterprise_name: this.enterprise_name,
                    pollution_source_name: this.pollution_source_name,
                    monitor_node_name: this.monitor_node_name
                };
                let res = await list(params);
                if (res.errno === 0) {
                    let data = res.data;
                    this.data = data
                    if (data.length > 0) {
                        let that = this
                        let data1 = []
                        let data2 = []
                        let data3 = []
                        data.forEach((item, index) => {
                            var content = ''
                            if (item.type === 1) {
                                content = `<img class="markerImg" src="http://52.81.152.99:8081/img/dw.gif"/>`
                                data1.push([item.name])
                            }
                            if (item.type === 2) {
                                content = `<div class="circle-marker-content">
                                            <div class="item item1" style='height:30px;width:30px;'></div>
                                            <div class="item item2" style='height:30px;width:30px;'></div>
                                            <div class="item item3" style='height:30px;width:30px;'></div>
                                            <div class="item item4" style='height:30px;width:30px;'></div>
                                            <div class="item item5" style='height:30px;width:30px;'></div>
                                        </div>`
                                data2.push([item.name])
                            }
                            if (item.type === 3) {
                                content = `<div class="monitorDevice">
                                            <span class="normalDevice"></span>
                                        </div>`
                                data3.push([item.name])
                            }
                            let marker = {
                                position: [item.longitude, item.latitude],
                                events: {
                                    mouseover () {
                                        // 方法：鼠标移动到点标记上，显示相应窗体
                                        that.windows.forEach(window => {
                                            window.visible = false // 关闭窗体
                                        })
                                        that.window = that.windows[index]
                                        that.$nextTick(() => {
                                            that.window.visible = true
                                        })
                                    },
                                    mouseout () {
                                        that.window.visible = false
                                    }
                                },
                                content: content
                            };
                            this.markers.push(marker)
                            this.windows.push({
                                position: [item.longitude, item.latitude],
                                isCustom: true,
                                offset: [150, 55], // 窗体偏移
                                showShadow: false,
                                visible: false, // 初始是否显示
                                name: item.name,
                                type: item.type,
                                address: item.address
                            })
                        })
                        this.config1 = {
                            columnWidth: [300],
                            oddRowBGC: '',
                            evenRowBGC: '',
                            data: data1
                        };
                        this.config2 = {
                            columnWidth: [300],
                            oddRowBGC: '',
                            evenRowBGC: '',
                            data: data2
                        };
                        this.config3 = {
                            columnWidth: [300],
                            oddRowBGC: '',
                            evenRowBGC: '',
                            data: data3
                        };
                    } else {
                        this.$Message['warning']({
                            content: '暂无数据',
                            duration: 3
                        });
                    }
                } else {
                    this.$Message['error']({
                        content: res.errmsg,
                        duration: 3
                    });
                };
            },
            showMapmaker (e) {
                for (var i in this.data) {
                    if (this.data[i].name === e.row[0]) {
                        let that = this;
                        that.windows.forEach(window => {
                            window.visible = false // 关闭窗体
                        })
                        that.window = that.windows[i]
                        that.$nextTick(() => {
                            that.window.visible = true
                        })
                    }
                }
            }
        }
    }
</script>
<style lang="less">
    .mapContent{
        width:110%;
        position:relative
    }
    .infoCount{
        position:absolute;
        top:20px;
        left:20px;
        width:170px
    }
    .infoCountItem{
        margin-bottom:20px;
        padding:10px;
        height:60px;
        background-color:rgba(255,255,255,0.2);
        border-radius:5px;
        display:flex;
        align-items: center;
        font-size:15px;
        color:#fff;
        box-shadow: inset 0 0 10px #0a54ea;
    }
    .infoCountItem img{
        margin-right:5px;
        width:35px;
        height:35px
    }
    .infoCountItem span{
        font-size:25px;
    }
    .itemActive{
        background-color:#2d8cf0;
        color:#fff
    }
    .search{
        position:absolute;
        top:20px;
        right:50px;
        margin-right:150px;
        display:flex;
        align-items:center;
        background-color:rgba(255,255,255,0.2);
        border-radius:5px;
        padding:10px;
        box-shadow: inset 0 0 10px #0a54ea;
    }
    .search p{
        margin-right:10px;
        // width:140px
    }
    .monitor{
        width:20px;
        height:20px;
        border-radius:10px;
        background-color:#08ed10;
        margin-right:10px;
        margin-left:8px
    }
    .pollutionSource{
        width:20px;
        height:20px;
        border-radius:10px;
        background-color:#e03906;
        margin-right:10px;
        margin-left:8px
    }
    @circleColor: #e03906;
    .amap-marker {
        .amap-marker-content {
            position: relative;
            .circle-marker-content {
                position: absolute;
                top: 30px;
                left: 0px;
                height: 10px;
                width: 10px;
                transform: translate(-50%, -50%);
                border-radius: 100%;
                text-align: center;
                background: @circleColor;
                border: 1px solid @circleColor;
                box-shadow: 0px 0px 14px @circleColor;
                .item_count {
                    position: absolute;
                    top: 50%;
                    left: 50%;
                    transform: translate(-50%, -50%);
                    color: #1C77C3;
                    font-weight: bold;
                    font-size: 13px;
                    z-index: 10;
                }
                @keyframes scaless {
                    0% {
                    transform: scale(0);
                    opacity: 1;
                    }

                    100% {
                    transform: scale(2);
                    opacity: 0;
                    }
                }
                .item {
                    width: 100%;
                    height: 100%;
                    position: absolute;
                    border-radius: 100%;
                    top: 50%;
                    left: 50%;
                    transform: translate(-50%, -50%);
                }

                .item:before {
                    content: "";
                    position: absolute;
                    left: 0px;
                    top: 0px;
                    display: inline-block;
                    width: 100%;
                    height: 100%;
                    border: 1px solid @circleColor;
                    border-radius: 100%;
                    opacity: 0;
                    background-color: @circleColor;
                    animation: scaless 5s infinite cubic-bezier(0, 0, 0.49, 1.02);
                }

                .item1:before {
                    animation-delay: 0s;
                }

                .item2:before {
                    animation-delay: 1s;
                }

                .item3:before {
                    animation-delay: 2s;
                }

                .item4:before {
                    animation-delay: 3s;
                }

                .item5::before {
                    animation-delay: 4s;
                }
            }
        }
    }
    .monitorDevice{
        text-align:center;
        margin: 0 auto;
        width: 35px;
        height: 35px;
        background-color: #61fc59;
        box-shadow:0px 0px 15px #08ed10;
        border-radius: 50%;
        -webkit-animation-name: 'alarmDeviceBreath';/*动画属性名，也就是我们前面keyframes定义的动画名*/
        -webkit-animation-duration: 1s;/*动画持续时间*/
        -webkit-animation-timing-function: ease; /*动画频率，和transition-timing-function是一样的*/
        -webkit-animation-delay: 0s;/*动画延迟时间*/
        -webkit-animation-iteration-count: infinite;/*定义循环资料，infinite为无限次*/
        -webkit-animation-direction: alternate;/*定义动画方式*/
    }
    @keyframes alarmDeviceBreath{
        0% {margin-left: 0;margin-top: 0;width:35px;height:35px;box-shadow:0px 0px 15px #08ed10;}
        100% {margin-left: 5px;margin-top: 5px;width:25px;height:25px;box-shadow:0px 0px 10px #08ed10;}
    }
    .normalDevice span,
    .offLineDevice span,
    .alarmDevice span{
        line-height:30px;
        font-size:13px;
        -webkit-animation-name: 'breathSpan';
        -webkit-animation-duration: 1s;
        -webkit-animation-timing-function: ease;
        -webkit-animation-delay: 0s;
        -webkit-animation-iteration-count: infinite;
        -webkit-animation-direction: alternate;
    }
    @keyframes breathSpan{
        0% {line-height:30px}
        100% {line-height:20px}
    }
    .markerImg{
        width:40px;
        height:40px
    }
    #info-window{
      width: 300px;
      padding: 10px;
      margin-left: 30px;
      color:#fff;
      background:rgba(255,255,255,0.2);
      border-radius: 4px;
    }
    #info-window span{
        font-weight: bold;
    }
</style>
<style lang="less" scoped>
:deep(.ivu-input){
        outline: none !important;
        background: transparent !important;
        border: none !important;
        outline: medium !important;
        color: #fff !important;
        border-bottom: 1px solid #fff !important;
        border-radius:0;
        &::-webkit-input-placeholder {
            color: #fff !important;
        }
    }
:deep(.ivu-input:focus){
    outline: none;
    border: none;
}

.enterpriseGun{
        position:absolute;
        top:85px;
        right:50px;
        margin-right:150px;
        background-color:rgba(255,255,255,0.2);
        border-radius:5px;
        padding:10px;
        color:#fff;
        box-shadow: inset 0 0 10px #0a54ea;
    }
.monitorGun{
        position:absolute;
        top:345px;
        right:50px;
        margin-right:150px;
        background-color:rgba(255,255,255,0.2);
        border-radius:5px;
        padding:10px;
        color:#fff;
        box-shadow: inset 0 0 10px #0a54ea;
    }
.pollutionGun{
        position:absolute;
        top:605px;
        right:50px;
        margin-right:150px;
        background-color:rgba(255,255,255,0.2);
        border-radius:5px;
        padding:10px;
        color:#fff;
        box-shadow: inset 0 0 10px #0a54ea;
    }
.guName{
    font-size:15px;
    margin-bottom: 2px;
    border-bottom:1px solid #fff
}
.zs{
        position:absolute;
        bottom:50px;
        left:20px;
    }
</style>
