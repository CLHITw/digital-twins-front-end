<template>
    <div>
        <Card :bordered="false" dis-hover class="ivu-mt">
            <div style="display:flex;align-items:center">
                <p style="margin-right:20px">监测点名称：<Input  style="width:200px;" v-model="monitor_node_name" clearable/></p>
                <Button style="margin-right:20px" icon="ios-search" type="primary" @click="getData()">搜索</Button>
                <Button style="margin-right:20px" type="primary" icon="md-add" @click="handleOpenAdd">新建</Button>
                <Upload action="/" :before-upload="beforeUpload" :show-upload-list="false">
                    <Button type="primary" icon="ios-cloud-upload-outline">导入</Button>
                </Upload>
            </div>
            <div class="ivu-inline-block ivu-fr">
                <Dropdown trigger="click">
                    <Tooltip class="ivu-ml" content="列设置" placement="top">
                        <i-link>
                            <Icon type="md-options" />
                        </i-link>
                    </Tooltip>
                    <DropdownMenu slot="list">
                        <div class="ivu-p-8">
                            <Row>
                                <Col span="12">列展示</Col>
                                <Col span="12" class="ivu-text-right">
                                    <i-link link-color @click.native="handleResetColumn">重置</i-link>
                                </Col>
                            </Row>
                        </div>
                        <Divider size="small" class="ivu-mt-8 ivu-mb-8" />
                        <li class="ivu-dropdown-item" v-for="item in columns" :key="item.title"  @click="item.show = !item.show">
                            <Checkbox v-model="item.show"></Checkbox>
                            <span>{{ item.title }}</span>
                        </li>
                    </DropdownMenu>
                </Dropdown>
            </div>
            <List item-layout="vertical" style="margin-top:30px">
                <Table  :columns="tableColumns" border :data="data" :loading="loading">
                    <template slot-scope="{ row }" slot="action">
                        <Button type="primary" size="small" style="margin-right: 5px" @click="edit(row)">编辑</Button>
                        <Button type="error" size="small" @click="remove(row.id,row.monitor_node_name)">删除</Button>
                    </template>
                </Table>
                <div class="ivu-mt ivu-text-center" slot="footer">
                    <Page :current.sync="page" :total="count" :pageSize="pageSize" show-total show-elevator :simple="isMobile" @on-change="getData()"></Page>
                </div>
            </List>
        </Card>
        <Modal v-model="showModel" :title="title" :loading="creating" @on-ok="actionControl" :transfer="false">
            <Form ref="infoData" :model="infoData" :rules="addRules" :label-width="120">
                <FormItem label="监测点：" prop="monitor_node_id">
                    <Select v-model="infoData.monitor_node_id">
                        <Option v-for="item in monitorNodeData" v-bind:key="item.id" :value="item.id">{{item.name}}</Option>
                    </Select>
                </FormItem>
                <FormItem label="设备编码：" prop="device_code">
                    <Input v-model="infoData.device_code" placeholder="请输入设备编码"/>
                </FormItem>
                <FormItem label="样品名称：" prop="sample_name">
                    <Input v-model="infoData.sample_name" placeholder="请输入样品名称"/>
                </FormItem>
                <FormItem label="污染来源：" prop="source">
                    <Input v-model="infoData.source" placeholder="请输入污染来源"/>
                </FormItem>
                <FormItem label="相似度：" prop="similarity">
                    <Input v-model="infoData.similarity" placeholder="请输入相似度"/>
                </FormItem>
                <FormItem label="超标：" prop="excess">
                    <Input v-model="infoData.excess" placeholder="请输入超标"/>
                </FormItem>
                <FormItem label="荧光峰1：" prop="peak1">
                    <Input v-model="infoData.peak1" placeholder="请输入指标值" style="width: 168px"/>
                </FormItem>
                <FormItem label="荧光峰2：" prop="peak2">
                    <Input v-model="infoData.peak2" placeholder="请输入指标值" style="width: 168px"/>
                </FormItem>
                <FormItem label="荧光峰3：" prop="peak3">
                    <Input v-model="infoData.peak3" placeholder="请输入指标值" style="width: 168px"/>
                </FormItem>
                <FormItem label="荧光强度1：" prop="intensity1">
                    <Input v-model="infoData.intensity1" placeholder="请输入指标值" style="width: 168px"/>
                </FormItem>
                <FormItem label="荧光强度2：" prop="intensity2">
                    <Input v-model="infoData.intensity2" placeholder="请输入指标值" style="width: 168px"/>
                </FormItem>
                <FormItem label="荧光强度3：" prop="intensity3">
                    <Input v-model="infoData.intensity3" placeholder="请输入指标值" style="width: 168px"/>
                </FormItem>
                <FormItem label="监测时间：" prop="time">
                    <DatePicker :value="infoData.time" type="datetime" placeholder="请选择时间" style="width: 200px" @on-change="changeTime" />
                </FormItem>
            </Form>
        </Modal>
    </div>
</template>
<script>
    import { mapState } from 'vuex';
    import { monitorNodeFluorescenceList, monitorNodeFluorescenceAdd, monitorNodeFluorescenceDelete, monitorNodeFluorescenceUpdate, monitorNodeFluorescenceImport } from '@api/monitorNodeFluorescence';
    import { monitorNodeSelect } from '@api/monitorNode';

    export default {
        name: 'monitorNodeFluorescence',
        data () {
            return {
                monitor_node_name: '',
                monitorNodeData: [],
                data: [],
                loading: false,
                page: 1,
                count: 0,
                pageSize: 10,
                columns: [
                    {
                        show: true,
                        title: '监测点名称',
                        key: 'monitor_node_name'
                    },
                    {
                        show: true,
                        title: '设备编码',
                        key: 'device_code'
                    },
                    {
                        show: true,
                        title: '样品名称',
                        key: 'sample_name'
                    },
                    {
                        show: true,
                        title: '污染来源',
                        key: 'source'
                    },
                    {
                        show: true,
                        title: '相似度',
                        key: 'similarity',
                        width: 80
                    },
                    {
                        show: true,
                        title: '超标',
                        key: 'excess'
                    },
                    {
                        show: true,
                        title: '荧光峰1',
                        key: 'peak1'
                    },
                    {
                        show: true,
                        title: '荧光峰2',
                        key: 'peak2'
                    },
                    {
                        show: true,
                        title: '荧光峰3',
                        key: 'peak3'
                    },
                    {
                        show: true,
                        title: '荧光强度1',
                        key: 'intensity1'
                    },
                    {
                        show: true,
                        title: '荧光强度2',
                        key: 'intensity2'
                    },
                    {
                        show: true,
                        title: '荧光强度3',
                        key: 'intensity3'
                    },
                    {
                        show: true,
                        title: '监测时间',
                        key: 'time',
                        width: 110
                    },
                    {
                        show: true,
                        title: '创建时间',
                        key: 'add_time',
                        width: 110
                    },
                    {
                        show: true,
                        title: '操作',
                        slot: 'action',
                        width: 130
                    }
                ],
                showModel: false,
                title: '',
                infoData: {
                    monitor_node_id: '',
                    device_code: '',
                    time: '',
                    code: '01',
                    sample_name: '',
                    source: '',
                    similarity: '',
                    excess: '',
                    peak1: '',
                    peak2: '',
                    peak3: '',
                    intensity1: '',
                    intensity2: '',
                    intensity3: ''
                },
                addRules: {
                    monitor_node_id: [
                        { required: true, message: '请选择监测点' }
                    ]
                },
                creating: true,
                updateIndex: -1,
                updateId: ''
            }
        },
        computed: {
            ...mapState('admin/layout', [
                'isMobile'
            ]),
            // 动态设置列
            tableColumns () {
                const columns = [...this.columns];
                return columns.filter(item => item.show);
            }
        },
        methods: {
            // 监测点
            async getMonitorNodeData () {
                let res = await monitorNodeSelect();
                if (res.errno === 0) {
                    this.monitorNodeData = res.data
                } else {
                    this.$Message['error']({
                        content: res.errmsg,
                        duration: 3
                    });
                };
            },
            // 列表
            async getData () {
                this.loading = true;
                let params = {
                    page: this.page,
                    monitor_node_name: this.monitor_node_name
                };
                let res = await monitorNodeFluorescenceList(params);
                if (res.errno === 0) {
                    this.data = res.data.data;
                    this.count = res.data.count;
                    this.pageSize = res.data.pageSize;
                } else {
                    this.$Message['error']({
                        content: res.errmsg,
                        duration: 3
                    });
                };
                this.loading = false;
            },
            // 添加
            handleOpenAdd () {
                this.title = '添加荧光光谱监测数据';
                this.updateIndex = -1;
                this.infoData = {
                    monitor_node_id: '',
                    device_code: '',
                    time: '',
                    code: '01',
                    sample_name: '',
                    source: '',
                    similarity: '',
                    excess: '',
                    peak1: '',
                    peak2: '',
                    peak3: '',
                    intensity1: '',
                    intensity2: '',
                    intensity3: ''
                };
                this.showModel = true;
            },
            // 编辑
            async edit (info) {
                this.title = '编辑荧光光谱监测数据'
                this.updateIndex = info.id;
                this.updateId = info.id;
                this.infoData.monitor_node_id = info.id;
                this.infoData.device_code = info.device_code;
                this.infoData.time = info.time;
                this.infoData.code = info.code;
                this.infoData.sample_name = info.sample_name;
                this.infoData.source = info.source;
                this.infoData.similarity = info.similarity;
                this.infoData.excess = info.excess;
                this.infoData.peak1 = info.peak1;
                this.infoData.peak2 = info.peak2;
                this.infoData.peak3 = info.peak3;
                this.infoData.intensity1 = info.intensity1;
                this.infoData.intensity2 = info.intensity2;
                this.infoData.intensity3 = info.intensity3;
                this.showModel = true
            },
            async actionControl () {
                this.$refs.infoData.validate(async (valid) => {
                    if (valid) {
                        if (this.updateIndex < 0) {
                            // 新建
                            let res = await monitorNodeFluorescenceAdd(this.infoData);
                            if (res.errno === 0) {
                                this.$Message.success(res.data);
                                this.showModel = false;
                                this.getData()
                            } else {
                                this.$Message.error(res.errmsg);
                            }
                        } else {
                            // 修改
                            let updateData = this.infoData;
                            updateData.id = this.updateId;
                            let res = await monitorNodeFluorescenceUpdate(updateData);
                            if (res.errno === 0) {
                                this.$Message.success(res.data);
                                this.showModel = false;
                                this.getData()
                            } else {
                                this.$Message.error(res.errmsg);
                            }
                        }
                        this.creating = false;
                        this.$nextTick(() => {
                            this.creating = true;
                        });
                    } else {
                        this.creating = false;
                        this.$nextTick(() => {
                            this.creating = true;
                        });
                    }
                });
            },
            changeTime (e) {
                this.infoData.time = e;
            },
            beforeUpload (file) {
                let that = this;
                this.$Table.import({
                    type: 'xlsx',
                    file: file,
                    finish: (res) => {
                        let data = res.data;
                        that.import(data)
                    }
                });
                return false;
            },
            async import (data) {
                let res = await monitorNodeFluorescenceImport({ data: data });
                if (res.errno === 0) {
                    let msg = '成功添加' + res.data.successCount + '条，失败' + res.data.failCount + '条'
                    this.$Message.success(msg);
                    this.getData()
                } else {
                    this.$Message.error(res.errmsg);
                }
            },
            // 删除
            remove (id, monitorNodeName) {
                this.$Modal.confirm({
                    title: '删除荧光光谱监测数据',
                    content: '确定删除荧光光谱监测数据：' + monitorNodeName + '吗？',
                    onOk: async () => {
                        let res = await monitorNodeFluorescenceDelete({ id: id });
                        if (res.errno === 0) {
                            this.$Message.success(res.data);
                            this.getData()
                        } else {
                            this.$Message.error(res.errmsg);
                        }
                    }
                });
            },
            // 重置表格列设置
            handleResetColumn () {
                this.columns = this.columns.map(item => {
                    const newItem = item;
                    newItem.show = true;
                    return newItem;
                });
            }
        },
        mounted () {
            this.getData();
            this.getMonitorNodeData();
        }
    }
</script>
