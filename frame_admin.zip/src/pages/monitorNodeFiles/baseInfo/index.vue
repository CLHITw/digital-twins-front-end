<template>
    <div>
        <Card :bordered="false" dis-hover class="ivu-mt">
            <div style="display:flex;align-items:center">
                <p style="margin-right:20px">监测点名称：<Input  style="width:200px;" v-model="name" clearable/></p>
                <Button style="margin-right:20px" icon="ios-search" type="primary" @click="getData()">搜索</Button>
                <Button style="margin-right:20px" type="primary" icon="md-add" @click="handleOpenAdd">新建</Button>
                <Upload  action="/" :before-upload="beforeUpload" :show-upload-list="false">
                    <Button type="primary" icon="ios-cloud-upload-outline">导入</Button>
                </Upload>
            </div>
            <div class="ivu-inline-block ivu-fr">
                <Dropdown trigger="click">
                    <Tooltip class="ivu-ml" content="列设置" placement="top">
                        <i-link>
                            <Icon type="md-options" />
                        </i-link>
                    </Tooltip>
                    <DropdownMenu slot="list">
                        <div class="ivu-p-8">
                            <Row>
                                <Col span="12">列展示</Col>
                                <Col span="12" class="ivu-text-right">
                                    <i-link link-color @click.native="handleResetColumn">重置</i-link>
                                </Col>
                            </Row>
                        </div>
                        <Divider size="small" class="ivu-mt-8 ivu-mb-8" />
                        <li class="ivu-dropdown-item" v-for="item in columns" :key="item.title"  @click="item.show = !item.show">
                            <Checkbox v-model="item.show"></Checkbox>
                            <span>{{ item.title }}</span>
                        </li>
                    </DropdownMenu>
                </Dropdown>
            </div>
            <List item-layout="vertical" style="margin-top:30px">
                <Table :columns="tableColumns" border :data="data" :loading="loading">
                    <template slot-scope="{ row }" slot="type">
                        <span v-if="row.type==1">国控</span>
                        <span v-if="row.type==2">省控</span>
                        <span v-if="row.type==3">市控</span>
                    </template>
                    <template slot-scope="{ row }" slot="action">
                        <Button type="primary" size="small" style="margin-right: 5px" @click="edit(row)">编辑</Button>
                        <Button type="error" size="small" @click="remove(row.id,row.name)">删除</Button>
                    </template>
                </Table>
                <div class="ivu-mt ivu-text-center" slot="footer">
                    <Page :current.sync="page" :total="count" :pageSize="pageSize" show-total show-elevator :simple="isMobile" @on-change="getData()"></Page>
                </div>
            </List>
        </Card>
        <Modal v-model="showModel" :title="title" :loading="creating" @on-ok="actionMonitorNode" :width="1000" :transfer="false">
            <Form ref="infoData" :model="infoData" :rules="addRules" :label-width="120">
                <Row :gutter="30">
                    <Col span="10">
                        <FormItem label="监测点名称：" prop="name">
                            <Input v-model="infoData.name" placeholder="请输入监测点名称" />
                        </FormItem>
                    </Col>
                    <Col span="14">
                        <FormItem label="位置坐标：" prop="coordinate">
                            经度：<Input style="width:150px" v-model="infoData.longitude" placeholder="请输入经度" />
                            纬度：<Input style="width:150px" v-model="infoData.latitude" placeholder="请输入纬度" />
                        </FormItem>
                        <div style="width:100%;height:350px;">
                            <el-amap :zoom="10" :center="center" :events="events" mapStyle="light">
                                <el-amap-marker v-if="markerPosition" :position="markerPosition" ></el-amap-marker>
                            </el-amap>
                        </div>
                    </Col>
                </Row>
            </Form>
        </Modal>
    </div>
</template>
<script>
    import { mapState } from 'vuex';
    import { monitorNodeList, monitorNodeAdd, monitorNodeDelete, monitorNodeUpdate, monitorNodeImport } from '@api/monitorNode';

    export default {
        name: 'monitorNode',
        data () {
            let self = this;
            return {
                name: '',
                data: [],
                loading: false,
                page: 1,
                count: 0,
                pageSize: 10,
                columns: [
                    {
                        show: true,
                        title: '监测点名称',
                        key: 'name'
                    },
                    {
                        show: true,
                        title: '河流',
                        key: 'river_name'
                    },
                    {
                        show: true,
                        title: '城市',
                        key: 'address'
                    },
                    {
                        show: true,
                        title: '类型',
                        slot: 'type'
                    },
                    {
                        show: true,
                        title: '创建时间',
                        key: 'add_time',
                        width: 180
                    },
                    {
                        show: true,
                        title: '操作',
                        slot: 'action',
                        width: 150
                    }
                ],
                showModel: false,
                title: '',
                infoData: {
                    name: '',
                    longitude: '',
                    latitude: ''
                },
                addRules: {
                    name: [
                        { required: true, message: '请输入监测点名称', trigger: 'blur' }
                    ]
                },
                creating: true,
                updateIndex: -1,
                updateId: '',
                center: [113.554177, 23.088718],
                events: {
                    click (e) {
                        let { lng, lat } = e.lnglat
                        self.markerPosition = [lng, lat]
                        self.infoData.longitude = lng;
                        self.infoData.latitude = lat
                    }
                },
                markerPosition: ''
            }
        },
        computed: {
            ...mapState('admin/layout', [
                'isMobile'
            ]),
            // 动态设置列
            tableColumns () {
                const columns = [...this.columns];
                return columns.filter(item => item.show);
            }
        },
        methods: {
            // 列表
            async getData () {
                this.loading = true;
                let params = {
                    page: this.page,
                    name: this.name
                };
                let res = await monitorNodeList(params);
                if (res.errno === 0) {
                    this.data = res.data.data;
                    this.count = res.data.count;
                    this.pageSize = res.data.pageSize;
                } else {
                    this.$Message['error']({
                        content: res.errmsg,
                        duration: 3
                    });
                };
                this.loading = false;
            },
            // 添加
            handleOpenAdd () {
                this.title = '添加污监测点';
                this.updateIndex = -1;
                this.infoData = {
                    name: '',
                    longitude: '',
                    latitude: ''
                };
                this.showModel = true;
            },
            // 编辑
            async edit (info) {
                this.title = '编辑监测点信息'
                this.updateIndex = info.id;
                this.updateId = info.id;
                this.infoData.name = info.name;
                this.infoData.longitude = info.longitude;
                this.infoData.latitude = info.latitude;
                if (info.longitude && info.latitude) {
                    this.center = [info.longitude, info.latitude]
                    this.markerPosition = [info.longitude, info.latitude]
                }
                this.showModel = true
            },
            async actionMonitorNode () {
                this.$refs.infoData.validate(async (valid) => {
                    if (valid) {
                        if (this.updateIndex < 0) {
                            // 新建
                            let res = await monitorNodeAdd(this.infoData);
                            if (res.errno === 0) {
                                this.$Message.success(res.data);
                                this.showModel = false;
                                this.getData()
                            } else {
                                this.$Message.error(res.errmsg);
                            }
                        } else {
                            // 修改
                            let updateData = this.infoData;
                            updateData.id = this.updateId;
                            let res = await monitorNodeUpdate(updateData);
                            if (res.errno === 0) {
                                this.$Message.success(res.data);
                                this.showModel = false;
                                this.getData()
                            } else {
                                this.$Message.error(res.errmsg);
                            }
                        }
                        this.creating = false;
                        this.$nextTick(() => {
                            this.creating = true;
                        });
                    } else {
                        this.creating = false;
                        this.$nextTick(() => {
                            this.creating = true;
                        });
                    }
                });
            },
            // 删除
            remove (id, name) {
                this.$Modal.confirm({
                    title: '删除监测点',
                    content: '确定删除监测点' + name + '吗？',
                    onOk: async () => {
                        let res = await monitorNodeDelete({ id: id });
                        if (res.errno === 0) {
                            this.$Message.success(res.data);
                            this.getData()
                        } else {
                            this.$Message.error(res.errmsg);
                        }
                    }
                });
            },
            beforeUpload (file) {
                let that = this;
                this.$Table.import({
                    type: 'xlsx',
                    file: file,
                    finish: (res) => {
                        let data = res.data;
                        that.import(data)
                    }
                });
                return false;
            },
            async import (data) {
                let res = await monitorNodeImport({ data: data });
                if (res.errno === 0) {
                    let msg = '成功添加' + res.data.successCount + '条，失败' + res.data.failCount + '条'
                    this.$Message.success(msg);
                    this.getData()
                } else {
                    this.$Message.error(res.errmsg);
                }
            },
            // 重置表格列设置
            handleResetColumn () {
                this.columns = this.columns.map(item => {
                    const newItem = item;
                    newItem.show = true;
                    return newItem;
                });
            }
        },
        mounted () {
            this.getData();
        }
    }
</script>
