<template>
    <div>
        <Card :bordered="false" dis-hover class="ivu-mt">
            <Input  style="width:300px;float:left;margin-right:20px" v-model="name" placeholder="请输入用户名关键字"  search enter-button @on-search="getData()"/>
            <Button type="primary" icon="md-add" @click="handleOpenAdd">新建</Button>
            <div class="ivu-inline-block ivu-fr">
                <Dropdown trigger="click">
                    <Tooltip class="ivu-ml" content="列设置" placement="top">
                        <i-link>
                            <Icon type="md-options" />
                        </i-link>
                    </Tooltip>
                    <DropdownMenu slot="list">
                        <div class="ivu-p-8">
                            <Row>
                                <Col span="12">列展示</Col>
                                <Col span="12" class="ivu-text-right">
                                    <i-link link-color @click.native="handleResetColumn">重置</i-link>
                                </Col>
                            </Row>
                        </div>
                        <Divider size="small" class="ivu-mt-8 ivu-mb-8" />
                        <li class="ivu-dropdown-item" v-for="item in columns" :key="item.title"  @click="item.show = !item.show">
                            <Checkbox v-model="item.show"></Checkbox>
                            <span>{{ item.title }}</span>
                        </li>
                    </DropdownMenu>
                </Dropdown>
            </div>
            <List item-layout="vertical" style="margin-top:20px">
                <Table  :columns="tableColumns" border :data="data" :loading="loading">
                    <template slot-scope="{ row }" slot="area">
                        {{row.province}}{{row.city}}{{row.county}}
                    </template>
                    <template slot-scope="{ row }" slot="status">
                        <Switch v-model="row.status" @on-change="statusChange(row)">
                            <span slot="close">禁</span>
                            <span slot="open">启</span>
                        </Switch>
                    </template>
                    <template slot-scope="{ row }" slot="action">
                        <Button type="primary" size="small" style="margin-right: 5px" @click="changePassword(row.id)">修改密码</Button>
                        <Button type="error" size="small" @click="remove(row.id,row.name)" v-if="row.id>1">删除</Button>
                    </template>
                </Table>
                <div class="ivu-mt ivu-text-center" slot="footer">
                    <Page :current.sync="page" :total="count" :pageSize="pageSize" show-total show-elevator :simple="isMobile" @on-change="getData()"></Page>
                </div>
            </List>
        </Card>
        <Modal v-model="showModel" :title="title" :loading="creating" @on-ok="actionAccount" :transfer="false">
            <Form ref="infoData" :model="infoData" :rules="addRules" :label-width="80">
                <FormItem label="用户名：" prop="name">
                    <Input v-model="infoData.name" placeholder="请输入用户名" />
                </FormItem>
                <FormItem label="账户：" prop="account">
                    <Input v-model="infoData.account" placeholder="请输入账户" />
                </FormItem>
                <FormItem label="密码：" prop="password">
                    <Input v-model="infoData.password" placeholder="请输入密码" />
                </FormItem>
            </Form>
        </Modal>
        <Modal v-model="changepa" title="修改密码"  @on-ok="cP" :transfer="false">
            <Input v-model="password1" placeholder="请输入新密码" />
        </Modal>
    </div>
</template>
<script>
    import { mapState } from 'vuex';
    import { accountList, accountAdd, accountUpdatePassword, accountDelete, accountUpdate } from '@api/account';

    export default {
        name: 'account_list',
        data () {
            return {
                id: '',
                password1: '',
                changepa: false,
                data: [],
                loading: false,
                name: '',
                page: 1,
                count: 0,
                pageSize: 10,
                columns: [
                    {
                        show: true,
                        title: '用户名',
                        key: 'name'
                    },
                    {
                        show: true,
                        title: '账户',
                        key: 'account'
                    },
                    {
                        show: true,
                        title: '状态',
                        slot: 'status'
                    },
                    {
                        show: true,
                        title: '创建时间',
                        key: 'add_time',
                        width: 180
                    },
                    {
                        show: true,
                        title: '操作',
                        slot: 'action',
                        width: 180
                    }
                ],
                showModel: false,
                title: '',
                infoData: {
                    name: '',
                    account: '',
                    password: ''
                },
                addRules: {
                    name: [
                        { required: true, message: '请输入用户名', trigger: 'blur' }
                    ],
                    account: [
                        { required: true, message: '请输入账户', trigger: 'blur' }
                    ],
                    password: [
                        { required: true, message: '请输入密码', trigger: 'blur' }
                    ]
                },
                creating: true
            }
        },
        computed: {
            ...mapState('admin/layout', [
                'isMobile'
            ]),
            // 动态设置列
            tableColumns () {
                const columns = [...this.columns];
                return columns.filter(item => item.show);
            }
        },
        methods: {
            // 列表
            async getData () {
                this.loading = true;
                let params = {
                    page: this.page,
                    name: this.name
                };
                let res = await accountList(params);
                if (res.errno === 0) {
                    let data = res.data.data;
                    for (var i in data) {
                        if (data[i].status === 0) {
                            data[i].status = true
                        } else {
                            data[i].status = false
                        };
                    };
                    this.data = data;
                    this.count = res.data.count;
                    this.pageSize = res.data.pageSize;
                } else {
                    this.$Message['error']({
                        content: res.errmsg,
                        duration: 3
                    });
                };
                this.loading = false;
            },
            // 添加
            handleOpenAdd () {
                this.title = '添加账户';
                this.infoData = {
                    name: '',
                    account: '',
                    password: ''
                };
                this.showModel = true;
            },
            async actionAccount () {
                this.$refs.infoData.validate(async (valid) => {
                    if (valid) {
                        // 新建
                        let res = await accountAdd(this.infoData);
                        if (res.errno === 0) {
                            this.$Message.success(res.data);
                            this.showModel = false;
                            this.getData()
                        } else {
                            this.$Message.error(res.errmsg);
                        }
                        this.creating = false;
                        this.$nextTick(() => {
                            this.creating = true;
                        });
                    } else {
                        this.creating = false;
                        this.$nextTick(() => {
                            this.creating = true;
                        });
                    }
                });
            },
            // 删除
            remove (id, name) {
                this.$Modal.confirm({
                    title: '删除账户',
                    content: '确定删除账户' + name + '吗？',
                    onOk: async () => {
                        let res = await accountDelete({ id: id });
                        if (res.errno === 0) {
                            this.$Message.success(res.data);
                            this.getData()
                        } else {
                            this.$Message.error(res.errmsg);
                        }
                    }
                });
            },
            // 禁用启用
            async statusChange (row) {
                let status = 0;
                if (row.status === true) {
                    status = 0;
                };
                let params = {
                    id: row.id,
                    status: status
                }
                let res = await accountUpdate(params);
                if (res.errno === 0) {
                    this.$Message.success(res.data);
                } else {
                    this.$Message.error(res.errmsg);
                }
            },
            // 重置表格列设置
            handleResetColumn () {
                this.columns = this.columns.map(item => {
                    const newItem = item;
                    newItem.show = true;
                    return newItem;
                });
            },
            // 修改密码
            changePassword (id) {
                this.id = id;
                this.password1 = '';
                this.changepa = true;
            },
            async cP () {
                if (!this.password1) {
                    this.$Message.warning('请输入新密码');
                } else {
                    let params = {
                        id: this.id,
                        password: this.password1
                    };
                    let res = await accountUpdatePassword(params);
                    if (res.errno === 0) {
                        this.$Message.success(res.data);
                        this.changepa = false;
                        this.getData()
                    } else {
                        this.$Message.error(res.errmsg);
                    }
                }
            }
        },
        mounted () {
            this.getData();
        }
    }
</script>
