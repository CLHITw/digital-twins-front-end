<template>
    <div>
        <Row :gutter="16">
            <Col span="8">
                <Card :bordered="false" dis-hover class="ivu-mt">
                    <div class="infoTotalCount">
                        <span class="pollutionSourceTitle">监测点</span>
                        <ul class="num-list">
                            <li class="num-item" v-for="(item,index) in count" :key="index">{{item}}</li>
                            <span>个</span>
                        </ul>
                    </div>
                </Card>
            </Col>
            <Col span="16">
                <Card :bordered="false" dis-hover class="ivu-mt">
                    <Row :gutter="20">
                        <Col span="8" style="height:200px">
                            <span class="pollutionSourceTitle">污染物</span>
                            <p class="pm">常规水质<span>{{contaminantCount.contaminant1}}</span>种</p>
                            <p class="pm">挥发性有机物<span>{{contaminantCount.contaminant2}}</span>种</p>
                            <p class="pm">重金属<span>{{contaminantCount.contaminant3}}</span>种</p>
                        </Col>
                        <Col span="16" style="display:flex;align-items: center;">
                            <tagcloud :data="contaminantData" :width="400" :height="400"></tagcloud>
                        </Col>
                    </Row>
                </Card>
            </Col>
            <Col span="24">
                <Card :bordered="false" dis-hover class="ivu-mt">
                    <div>
                        <span class="pollutionSourceTitle">监测点监控历史</span>
                        <div style="display:flex;align-items:center;margin-top:5px">
                            <p style="margin-right:20px;display:flex;align-items:center;">
                                <Select v-model="monitor_node_id" style="width:200px;" clearable placeholder="请选择监测点">
                                    <Option v-for="item in monitorNodeData" v-bind:key="item.id" :value="item.id">{{item.name}}</Option>
                                </Select>
                            </p>
                            <p style="margin-right:20px;display:flex;align-items:center;">
                                <Select v-model="contaminant_id" style="width:200px;" clearable placeholder="请选择污染物">
                                    <Option v-for="item in contaminantData" v-bind:key="item.id" :value="item.id">{{item.name}}</Option>
                                </Select>
                            </p>
                            <p style="margin-right:20px;display:flex;align-items:center;">
                                <DatePicker style="width:350px" type="datetimerange" placeholder="请选择时间段" @on-change="selectTime"></DatePicker>
                            </p>
                            <Button style="margin-right:20px" icon="ios-search" type="primary" @click="monitorHistory()">检索</Button>
                        </div>
                        <div ref="monitorHistory" v-height="300"></div>
                    </div>
                </Card>
            </Col>
            <Col span="24">
                <Card :bordered="false" dis-hover class="ivu-mt">
                    <div>
                        <span class="pollutionSourceTitle">监测点荧光光谱历史</span>
                        <div style="display:flex;align-items:center;margin-top:5px">
                            <p style="margin-right:20px;display:flex;align-items:center;">
                                <Select v-model="monitor_node_id1" style="width:200px;" clearable placeholder="请选择监测点">
                                    <Option v-for="item in monitorNodeData" v-bind:key="item.id" :value="item.id">{{item.name}}</Option>
                                </Select>
                            </p>
                            <p style="margin-right:20px;display:flex;align-items:center;">
                                <DatePicker style="width:350px" type="datetimerange" placeholder="请选择时间段" @on-change="selectTime1"></DatePicker>
                            </p>
                            <Button style="margin-right:20px" icon="ios-search" type="primary" @click="fluorescenceHistory()">检索</Button>
                        </div>
                        <div ref="fluorescenceHistory" v-height="300"></div>
                    </div>
                </Card>
            </Col>
        </Row>
    </div>
</template>
<script>
    import echarts from 'echarts';
    import { mapState } from 'vuex';
    import { monitorNode, contaminant, monitorModeContaminant, monitorModeFluorescence } from '@api/statistical';
    import tagcloud from '../../../components/tagCloud';
    export default {
        name: 'monitorNode',
        components: {
            tagcloud
        },
        data () {
            return {
                contaminantCount: {
                    contaminant1: 0,
                    contaminant2: 0,
                    contaminant3: 0
                },
                contaminantData: [],
                monitorNodeData: [],
                info: {},
                count: [],
                contaminant_id: [],
                monitor_node_id: '',
                start_time: '',
                end_time: '',
                monitor_node_id1: '',
                start_time1: '',
                end_time1: ''
            }
        },
        computed: {
            ...mapState('admin/layout', [
                'isMobile'
            ])
        },
        methods: {
            async getContaminantData () {
                let res = await contaminant();
                if (res.errno === 0) {
                    this.contaminantData = res.data;
                    for (var i in this.contaminantData) {
                        if (this.contaminantData[i].type === 1) {
                            this.contaminantCount.contaminant1++
                        } else if (this.contaminantData[i].type === 2) {
                            this.contaminantCount.contaminant2++
                        } else {
                            this.contaminantCount.contaminant3++
                        }
                    }
                } else {
                    this.$Message['error']({
                        content: res.errmsg,
                        duration: 3
                    });
                };
            },
            async getData () {
                let res = await monitorNode();
                if (res.errno === 0) {
                    this.info = res.data;
                    let totalCount = this.info.totalCount.toString();
                    for (var i = 0, len = totalCount.length; i < len; i += 1) {
                        this.count.push(totalCount[i])
                    };
                    this.monitorNodeData = this.info.list
                } else {
                    this.$Message['error']({
                        content: res.errmsg,
                        duration: 3
                    });
                };
            },
            selectTime (e) {
                this.start_time = e[0];
                this.end_time = e[1]
            },
            async monitorHistory () {
                let params = {
                    monitor_node_id: this.monitor_node_id,
                    contaminant_id: this.contaminant_id,
                    start_time: this.start_time,
                    end_time: this.end_time
                }
                let res = await monitorModeContaminant(params);
                if (res.errno === 0) {
                    let data = res.data;
                    let xData = [];
                    let yData = []
                    for (var i in data) {
                        xData.push(data[i].time)
                        yData.push(data[i].count)
                    }
                    var myChart = echarts.init(this.$refs.monitorHistory);
                    let option = {
                        tooltip: {
                            trigger: 'axis'
                        },
                        grid: {
                            left: '3%',
                            right: '4%',
                            bottom: '3%',
                            containLabel: true
                        },
                        xAxis: {
                            type: 'category',
                            data: xData
                        },
                        yAxis: {
                            type: 'value'
                        },
                        series: [
                            {
                                data: yData,
                                type: 'line'
                            }
                        ]
                    };
                    myChart.setOption(option)
                } else {
                    this.$Message['error']({
                        content: res.errmsg,
                        duration: 3
                    });
                };
            },
            selectTime1 (e) {
                this.start_time1 = e[0];
                this.end_time1 = e[1]
            },
            async fluorescenceHistory () {
                let params = {
                    monitor_node_id: this.monitor_node_id1,
                    start_time: this.start_time1,
                    end_time: this.end_time1
                }
                let res = await monitorModeFluorescence(params);
                if (res.errno === 0) {
                    console.log(res)
                    let data = res.data;
                    let xData = [];
                    let yData1 = [];
                    let yData2 = [];
                    let yData3 = [];
                    for (var i in data) {
                        xData.push(data[i].time)
                        yData1.push(data[i].intensity1)
                        yData2.push(data[i].intensity2)
                        yData3.push(data[i].intensity3)
                    }
                    let option = {
                        tooltip: {
                            trigger: 'axis'
                        },
                        legend: {
                            data: ['荧光强度1', '荧光强度2', '荧光强度3']
                        },
                        grid: {
                            left: '3%',
                            right: '4%',
                            bottom: '3%',
                            containLabel: true
                        },
                        xAxis: {
                            type: 'category',
                            boundaryGap: false,
                            data: xData
                        },
                        yAxis: {
                            type: 'value'
                        },
                        series: [
                            {
                                name: '荧光强度1',
                                type: 'line',
                                stack: 'Total',
                                data: yData1
                            },
                            {
                                name: '荧光强度2',
                                type: 'line',
                                stack: 'Total',
                                data: yData2
                            },
                            {
                                name: '荧光强度3',
                                type: 'line',
                                stack: 'Total',
                                data: yData3
                            }
                        ]
                    };
                    var myChart = echarts.init(this.$refs.fluorescenceHistory);
                    myChart.setOption(option)
                } else {
                    this.$Message['error']({
                        content: res.errmsg,
                        duration: 3
                    });
                };
            }
        },
        mounted () {
            this.getContaminantData()
            this.getData()
        }
    }
</script>
<style scoped>
    .infoTotalCount{
        font-size:15px;
        height:400px
    }
    .pollutionSourceTitle{
        color:#333;
        margin-left:3px
    }
    .num-list{
        display: flex;
        -webkit-box-align: center;
        align-items: center;
        list-style: none;
        flex-grow: 1;
        justify-content: center;
        height:150px
    }
    .num-item{
        width: 52px;
        height: 61px;
        font-size: 30px;
        text-align: center;
        background-image: url('../../../assets/images/countBg.png');
        background-repeat: no-repeat;
        background-size: 100% 100%;
        font-family: "vcrscs";
        line-height: 2;
        color:#fff;
        margin-right:5px;
    }
    .common-title{
        text-align:center;
        background: #468eee;
        color: #fff;
        display: inline-block;
        margin-bottom:10px;
        height: 25px;
        line-height: 25px;
        font-size: 16px;
        padding: 0 10px;
        position: relative;
    }
    .common-title::after{
        display: block;
        content: "";
        position: absolute;
        width: 0;
        height: 0;
        border-bottom: 30px solid #468eee;
        border-right: 30px solid transparent;
        right: -30px;
        top: 0;
    }
    .pm{
        padding:3px 0px 3px 5px;
        display: flex;
        align-items: center;
        font-size:13px
    }
    .pm span{
        flex-grow: 1;
        text-align: right;
        font-size:23px
    }
</style>
