<template>
    <div>
        <Row :gutter="16">
            <Col span="8">
                <Card :bordered="false" dis-hover class="ivu-mt">
                    <div class="infoTotalCount">
                        <span class="pollutionSourceTitle">污染源</span>
                        <ul class="num-list">
                            <li class="num-item" v-for="(item,index) in count" :key="index">{{item}}</li>
                            <span>个</span>
                        </ul>
                    </div>
                </Card>
            </Col>
            <Col span="8">
                <Card :bordered="false" dis-hover class="ivu-mt">
                    <div ref="dealwithFacilities" v-height="200"></div>
                </Card>
            </Col>
            <Col span="8">
                <Card :bordered="false" dis-hover class="ivu-mt">
                    <div ref="dealwithWay" v-height="200"></div>
                </Card>
            </Col>
            <Col span="24">
                <Card :bordered="false" dis-hover class="ivu-mt">
                    <div ref="whereabouts" v-height="200"></div>
                </Card>
            </Col>
            <Col span="24">
                <Card :bordered="false" dis-hover class="ivu-mt">
                    <div ref="acceptWater" v-height="200"></div>
                </Card>
            </Col>
            <Col span="24">
                <Card :bordered="false" dis-hover class="ivu-mt">
                    <div ref="gx" v-height="1000"></div>
                </Card>
            </Col>
        </Row>
    </div>
</template>
<script>
    import echarts from 'echarts';
    import { mapState } from 'vuex';
    import { pollutionSource } from '@api/statistical';
    export default {
        name: 'pollution_source',
        data () {
            return {
                info: {},
                count: [],
                timer: '',
                timer1: ''
            }
        },
        computed: {
            ...mapState('admin/layout', [
                'isMobile'
            ])
        },
        methods: {
            async getData () {
                let res = await pollutionSource();
                if (res.errno === 0) {
                    this.info = res.data;
                    let totalCount = this.info.totalCount.toString();
                    for (var i = 0, len = totalCount.length; i < len; i += 1) {
                        this.count.push(totalCount[i])
                    }
                    this.dealwithFacilities()
                    this.dealwithWay()
                    this.whereabouts()
                    this.acceptWater()
                    this.gx()
                } else {
                    this.$Message['error']({
                        content: res.errmsg,
                        duration: 3
                    });
                };
            },
            dealwithFacilities () {
                var myChart = echarts.init(this.$refs.dealwithFacilities);
                let option = {
                    title: {
                        text: '污水处理设施',
                        left: 'left',
                        textStyle: {
                            fontSize: 15,
                            fontWeight: 'normal'
                        }
                    },
                    tooltip: {
                        trigger: 'item',
                        formatter: '{b} : {c}'
                    },
                    legend: {
                        orient: 'vertical',
                        left: 'right',
                        padding: [0, 10]
                    },
                    series: [
                        {
                            type: 'pie',
                            radius: ['40%', '70%'],
                            avoidLabelOverlap: false,
                            itemStyle: {
                                borderRadius: 10,
                                borderColor: '#fff',
                                borderWidth: 2
                            },
                            label: {
                                show: false
                            },
                            labelLine: {
                                show: false
                            },
                            data: this.info.dealwith_facilities,
                            color: [
                                '#409eff',
                                '#36F2F2',
                                '#FC38A4',
                                '#F87930',
                                '#59FD29',
                                '#5FD879',
                                '#92b5d6'
                            ]
                        }
                    ]
                };
                myChart.setOption(option)
                let curIndex = 0;
                this.timer = setInterval(function () {
                    var dataLen = option.series[0].data.length;
                    myChart.dispatchAction({ type: 'downplay', seriesIndex: 0, dataIndex: curIndex });
                    curIndex = (curIndex + 1) % dataLen
                    myChart.dispatchAction({
                        type: 'highlight', seriesIndex: 0, dataIndex: curIndex
                    });
                    myChart.dispatchAction({
                        type: 'showTip',
                        seriesIndex: 0,
                        dataIndex: curIndex
                    })
                }, 2000);
            },
            dealwithWay () {
                var myChart = echarts.init(this.$refs.dealwithWay);
                let option = {
                    title: {
                        text: '污水处理方法',
                        left: 'left',
                        textStyle: {
                            fontSize: 15,
                            fontWeight: 'normal'
                        }
                    },
                    tooltip: {
                        trigger: 'item',
                        formatter: '{b} : {c}'
                    },
                    legend: {
                        orient: 'vertical',
                        left: 'right',
                        padding: [0, 10]
                    },
                    series: [
                        {
                            type: 'pie',
                            radius: ['40%', '70%'],
                            avoidLabelOverlap: false,
                            itemStyle: {
                                borderRadius: 10,
                                borderColor: '#fff',
                                borderWidth: 2
                            },
                            label: {
                                show: false
                            },
                            labelLine: {
                                show: false
                            },
                            data: this.info.dealwith_way,
                            color: [
                                '#409eff',
                                '#36F2F2',
                                '#FC38A4',
                                '#F87930',
                                '#59FD29',
                                '#5FD879',
                                '#92b5d6'
                            ]
                        }
                    ]
                };
                myChart.setOption(option)
                let curIndex = 0;
                this.timer1 = setInterval(function () {
                    var dataLen = option.series[0].data.length;
                    myChart.dispatchAction({ type: 'downplay', seriesIndex: 0, dataIndex: curIndex });
                    curIndex = (curIndex + 1) % dataLen
                    myChart.dispatchAction({
                        type: 'highlight', seriesIndex: 0, dataIndex: curIndex
                    });
                    myChart.dispatchAction({
                        type: 'showTip',
                        seriesIndex: 0,
                        dataIndex: curIndex
                    })
                }, 2000);
            },
            whereabouts () {
                var myChart = echarts.init(this.$refs.whereabouts);
                let option = {
                    title: {
                        text: '排水去向',
                        left: 'left',
                        textStyle: {
                            fontSize: 15,
                            fontWeight: 'normal'
                        }
                    },
                    tooltip: {
                        trigger: 'item',
                        formatter: '{b} : {c}'
                    },
                    xAxis: {
                        type: 'category',
                        axisLine: {
                            'show': false
                        },
                        axisTick: {
                            'show': false
                        },
                        axisLabel: {
                            interval: 0
                        },
                        data: this.info.whereaboutsX
                    },
                    yAxis: {
                        axisLabel: {
                            formatter: function () {
                                return '';
                            }
                        },
                        dispaly: 'none',
                        'axisLine': {
                            'show': false
                        },
                        'axisTick': {
                            'show': false
                        },
                        'splitLine': {
                            'show': false
                        },
                        'show': true
                    },
                    series: [
                        {
                            data: this.info.whereaboutsY,
                            type: 'bar',
                            barWidth: 30,
                            color: ['#409eff']
                        }
                    ]
                };
                myChart.setOption(option)
            },
            acceptWater () {
                var myChart = echarts.init(this.$refs.acceptWater);
                let option = {
                    title: {
                        text: '受纳水体',
                        left: 'left',
                        textStyle: {
                            fontSize: 15,
                            fontWeight: 'normal'
                        }
                    },
                    tooltip: {
                        trigger: 'item',
                        formatter: '{b} : {c}'
                    },
                    xAxis: {
                        type: 'category',
                        axisLine: {
                            'show': false
                        },
                        axisTick: {
                            'show': false
                        },
                        axisLabel: {
                            interval: 0
                        },
                        data: this.info.acceptWaterX
                    },
                    yAxis: {
                        axisLabel: {
                            formatter: function () {
                                return '';
                            }
                        },
                        dispaly: 'none',
                        'axisLine': {
                            'show': false
                        },
                        'axisTick': {
                            'show': false
                        },
                        'splitLine': {
                            'show': false
                        },
                        'show': true
                    },
                    series: [
                        {
                            data: this.info.acceptWaterY,
                            type: 'bar',
                            barWidth: 30,
                            color: ['#409eff']
                        }
                    ]
                };
                myChart.setOption(option)
            },
            gx () {
                var myChart = echarts.init(this.$refs.gx);
                let option = {
                    title: {
                        text: '污染源企业关系图',
                        left: 'left',
                        textStyle: {
                            fontSize: 15,
                            fontWeight: 'normal'
                        }
                    },
                    legend: [
                        {
                            left: 'right',
                            padding: [0, 10],
                            data: this.info.categoriesList.map(function (a) {
                                return a.name;
                            })
                        }
                    ],
                    animationDuration: 1500,
                    animationEasingUpdate: 'quinticInOut',
                    series: [
                        {
                            type: 'graph',
                            layout: 'force', // force、circular
                            draggable: true,
                            data: this.info.nodeList,
                            links: this.info.linkList,
                            categories: this.info.categoriesList,
                            roam: true,
                            label: {
                                position: 'right',
                                formatter: '{b}'
                            },
                            lineStyle: {
                                color: 'source',
                                curveness: 0.3
                            },
                            emphasis: {
                                focus: 'adjacency',
                                lineStyle: {
                                    width: 10
                                }
                            },
                            color: [
                                '#409eff',
                                '#36F2F2',
                                '#FC38A4',
                                '#F87930',
                                '#59FD29',
                                '#5FD879',
                                '#92b5d6'
                            ]
                        }
                    ]
                };
                myChart.setOption(option)
            }
        },
        mounted () {
            this.getData()
        },
        destroyed () {
            clearInterval(this.timer)
            clearInterval(this.timer1)
        }
    }
</script>
<style scoped>
    .infoTotalCount{
        font-size:15px;
        height:200px
    }
    .pollutionSourceTitle{
        color:#333;
        margin-left:3px
    }
    .num-list{
        display: flex;
        -webkit-box-align: center;
        align-items: center;
        list-style: none;
        flex-grow: 1;
        justify-content: center;
        height:150px
    }
    .num-item{
        width: 52px;
        height: 61px;
        font-size: 30px;
        text-align: center;
        background-image: url('../../../assets/images/countBg.png');
        background-repeat: no-repeat;
        background-size: 100% 100%;
        font-family: "vcrscs";
        line-height: 2;
        color:#fff;
        margin-right:5px;
    }
    .common-title{
        text-align:center;
        background: #468eee;
        color: #fff;
        display: inline-block;
        margin-bottom:10px;
        height: 25px;
        line-height: 25px;
        font-size: 16px;
        padding: 0 10px;
        position: relative;
    }
    .common-title::after{
        display: block;
        content: "";
        position: absolute;
        width: 0;
        height: 0;
        border-bottom: 30px solid #468eee;
        border-right: 30px solid transparent;
        right: -30px;
        top: 0;
    }
</style>
