<template>
    <div>
        <Row :gutter="10">
            <Col span="12">
                <Card :bordered="false" dis-hover class="ivu-mt">
                    <div style="display:flex;align-items:center">
                        <p style="margin-right:10px">企业名称：<Input  style="width:200px;" v-model="enterprise_name" clearable/></p>
                        <!-- <p style="margin-right:20px">社会统一代码：<Input  style="width:200px;" v-model="id_no" clearable/></p> -->
                        <p style="margin-right:20px;display:flex;align-items:center;">年份：
                            <DatePicker :value="year" type="year" format="yyyy" style="width: 100px" @on-change="selectYear"/>
                        </p>
                        <Button style="margin-right:10px" icon="ios-search" type="primary" @click="getData()">搜索</Button>
                        <Button style="margin-right:10px" type="primary" icon="md-add" @click="handleOpenAdd">添加</Button>
                        <Upload  action="/" :before-upload="beforeUpload" :show-upload-list="false">
                            <Button type="primary" icon="ios-cloud-upload-outline">导入</Button>
                        </Upload>
                    </div>
                    <List item-layout="vertical" style="margin-top:20px">
                        <Table highlight-row :columns="columns" border :data="data" :loading="loading" @on-current-change="selectRow">
                            <template slot-scope="{ row }" slot="action">
                                <Button type="error" size="small" @click="remove(row.id,row.enterprise_name,row.year)">删除</Button>
                            </template>
                        </Table>
                        <div class="ivu-mt ivu-text-center" slot="footer">
                            <Page :current.sync="page" :total="count" :pageSize="pageSize" show-total show-elevator :simple="isMobile" @on-change="getData()"></Page>
                        </div>
                    </List>
                </Card>
            </Col>
            <Col  span="12">
                <Card :bordered="false" dis-hover class="ivu-mt">
                    <div v-if="detailTitle" style="display:flex;align-items:center;margin-bottom:10px">
                        <p style="font-size:18px;color:#333;margin-right:20px">{{detailTitle}}</p>
                        <Button type="primary" icon="md-add" @click="handleOpenDetailAdd">添加</Button>
                    </div>
                    <Table  :columns="columns1" border :data="detailData">
                        <template slot-scope="{ row }" slot="action">
                            <Button type="error" size="small" @click="removeDetail(row.id,row.outlet_name)">删除</Button>
                        </template>
                    </Table>
                </Card>
            </Col>
        </Row>
        <Modal v-model="showModel" :title="title" :loading="creating" @on-ok="actionYearsData" :transfer="false">
            <Form ref="infoData" :model="infoData" :rules="addRules" :label-width="120">
                <FormItem label="企业：" prop="enterprise_id">
                    <Select v-model="infoData.enterprise_id" label-in-value @on-change="selectEnterprise">
                        <Option v-for="item in enterpriseData" v-bind:key="item.id" :value="item.id">{{item.name}}</Option>
                    </Select>
                </FormItem>
                <FormItem label="年份：" prop="year">
                    <DatePicker :value="infoData.year" type="year" format="yyyy" style="width: 100px" @on-change="selectYearAdd"/>
                </FormItem>
            </Form>
        </Modal>
        <Modal v-model="addDetailModel" :title="title" :loading="creating" @on-ok="actionYearsDetail" :transfer="false">
            <Form ref="infoDetail" :model="infoDetail" :rules="addRules1" :label-width="120">
                <FormItem label="污染物名称：" prop="outlet_name">
                    <Input v-model="infoDetail.outlet_name" placeholder="请输入污染物名称" />
                </FormItem>
                <FormItem label="数量：" prop="outlet_value">
                    <Input v-model="infoDetail.outlet_value" placeholder="请输入数量" />
                </FormItem>
            </Form>
        </Modal>
    </div>
</template>
<script>
    import { mapState } from 'vuex';
    import { enterpriseOutletYearsList, enterpriseOutletYearsAdd, enterpriseOutletYearsDelete, enterpriseOutletYearsDetailList, enterpriseOutletYearsDetailAdd, enterpriseOutletYearsDetailDelete, enterpriseOutletYearsImport } from '@api/enterpriseOutletYears';
    import { enterpriseSelect } from '@api/enterprise';

    export default {
        name: 'enterpriseOutletYears',
        data () {
            return {
                enterpriseData: [],
                enterprise_name: '',
                year: '',
                data: [],
                loading: false,
                page: 1,
                count: 0,
                pageSize: 10,
                columns: [
                    {
                        show: true,
                        title: '企业名称',
                        key: 'enterprise_name'
                    },
                    {
                        show: true,
                        title: '年份',
                        key: 'year',
                        width: 120
                    },
                    {
                        show: true,
                        title: '操作',
                        slot: 'action',
                        align: 'center',
                        width: 80
                    }
                ],
                detailTitle: '',
                detailData: [],
                columns1: [
                    {
                        show: true,
                        title: '污染物名称',
                        key: 'outlet_name'
                    },
                    {
                        show: true,
                        title: '数量',
                        key: 'outlet_value',
                        width: 200
                    },
                    {
                        show: true,
                        title: '操作',
                        slot: 'action',
                        align: 'center',
                        width: 150
                    }
                ],
                showModel: false,
                title: '',
                infoData: {
                    enterprise_id: '',
                    enterprise_name: '',
                    year: ''
                },
                addRules: {
                    enterprise_id: [
                        { required: true, message: '请选择企业' }
                    ]
                },
                creating: true,
                enterpriseOutletYearsId: '',
                addDetailModel: false,
                infoDetail: {
                    enterprise_outlet_years_id: '',
                    outlet_name: '',
                    outlet_value: ''
                },
                addRules1: {
                    outlet_name: [
                        { required: true, message: '请输入排放物', trigger: 'blur' }
                    ]
                }
            }
        },
        computed: {
            ...mapState('admin/layout', [
                'isMobile'
            ])
        },
        methods: {
            // 企业
            async getEnterpriseData () {
                let res = await enterpriseSelect();
                if (res.errno === 0) {
                    this.enterpriseData = res.data
                } else {
                    this.$Message['error']({
                        content: res.errmsg,
                        duration: 3
                    });
                };
            },
            // 选择年份
            selectYear (e) {
                this.year = e
            },
            selectYearAdd (e) {
                this.infoData.year = e
            },
            selectEnterprise (e) {
                if (e) {
                    this.infoData.enterprise_id = e.value;
                    this.infoData.enterprise_name = e.label;
                }
            },
            // 列表
            async getData () {
                this.loading = true;
                let params = {
                    page: this.page,
                    year: this.year,
                    enterprise_name: this.enterprise_name
                };
                let res = await enterpriseOutletYearsList(params);
                if (res.errno === 0) {
                    this.data = res.data.data;
                    this.count = res.data.count;
                    this.pageSize = res.data.pageSize;
                } else {
                    this.$Message['error']({
                        content: res.errmsg,
                        duration: 3
                    });
                };
                this.loading = false;
            },
            // 添加
            handleOpenAdd () {
                this.title = '添加企业环保年度';
                this.infoData = {
                    enterprise_id: '',
                    enterprise_name: '',
                    year: ''
                };
                this.showModel = true;
            },
            async actionYearsData () {
                this.$refs.infoData.validate(async (valid) => {
                    if (valid) {
                        let res = await enterpriseOutletYearsAdd(this.infoData);
                        if (res.errno === 0) {
                            this.$Message.success(res.data);
                            this.showModel = false;
                            this.getData();
                        } else {
                            this.$Message.error(res.errmsg);
                        }
                        this.creating = false;
                        this.$nextTick(() => {
                            this.creating = true;
                        });
                    } else {
                        this.creating = false;
                        this.$nextTick(() => {
                            this.creating = true;
                        });
                    }
                });
            },
            // 删除
            remove (id, name, year) {
                this.$Modal.confirm({
                    title: '删除企业环保年度数据',
                    content: '确定删除' + name + year + '企业环保年度数据吗？',
                    onOk: async () => {
                        let res = await enterpriseOutletYearsDelete({ id: id });
                        if (res.errno === 0) {
                            this.$Message.success(res.data);
                            this.getData()
                        } else {
                            this.$Message.error(res.errmsg);
                        }
                    }
                });
            },
            selectRow (e) {
                this.infoDetail.enterprise_outlet_years_id = e.id
                this.detailTitle = e.enterprise_name + e.year + '环保数据'
                this.getDetail()
            },
            async getDetail () {
                let params = {
                    id: this.infoDetail.enterprise_outlet_years_id
                };
                let res = await enterpriseOutletYearsDetailList(params);
                if (res.errno === 0) {
                    this.detailData = res.data;
                } else {
                    this.$Message['error']({
                        content: res.errmsg,
                        duration: 3
                    });
                };
            },
            handleOpenDetailAdd () {
                this.title = '添加环保数据'
                this.infoDetail.outlet_name = '';
                this.infoDetail.outlet_value = '';
                this.addDetailModel = true
            },
            async actionYearsDetail () {
                this.$refs.infoDetail.validate(async (valid) => {
                    if (valid) {
                        let res = await enterpriseOutletYearsDetailAdd(this.infoDetail);
                        if (res.errno === 0) {
                            this.$Message.success(res.data);
                            this.addDetailModel = false;
                            this.getDetail();
                        } else {
                            this.$Message.error(res.errmsg);
                        }
                        this.creating = false;
                        this.$nextTick(() => {
                            this.creating = true;
                        });
                    } else {
                        this.creating = false;
                        this.$nextTick(() => {
                            this.creating = true;
                        });
                    }
                });
            },
            removeDetail (id, name) {
                this.$Modal.confirm({
                    title: '删除数据',
                    content: '确定删除' + name + '数据吗？',
                    onOk: async () => {
                        let res = await enterpriseOutletYearsDetailDelete({ id: id });
                        if (res.errno === 0) {
                            this.$Message.success(res.data);
                            this.getDetail()
                        } else {
                            this.$Message.error(res.errmsg);
                        }
                    }
                });
            },
            beforeUpload (file) {
                let that = this;
                this.$Table.import({
                    type: 'xlsx',
                    file: file,
                    finish: (res) => {
                        let data = res.data;
                        that.import(data)
                    }
                });
                return false;
            },
            async import (data) {
                let res = await enterpriseOutletYearsImport({ data: data });
                if (res.errno === 0) {
                    let msg = '成功添加' + res.data.successCount + '条，失败' + res.data.failCount + '条'
                    this.$Message.success(msg);
                    this.getData()
                } else {
                    this.$Message.error(res.errmsg);
                }
            }
        },
        mounted () {
            this.getData();
            this.getEnterpriseData()
        }
    }
</script>
