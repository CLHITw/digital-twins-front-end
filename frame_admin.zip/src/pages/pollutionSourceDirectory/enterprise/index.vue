<template>
    <div>
        <Card :bordered="false" dis-hover class="ivu-mt">
            <div style="display:flex;align-items:center">
                <p style="margin-right:20px">企业名称：<Input  style="width:200px;" v-model="name" clearable/></p>
                <p style="margin-right:20px">社会统一代码：<Input  style="width:200px;" v-model="id_no" clearable/></p>
                <p style="margin-right:20px;display:flex;align-items:center;">行业：
                    <Select v-model="industry_id" style="width:200px;" clearable>
                        <Option v-for="item in industryData" v-bind:key="item.id" :value="item.id">{{item.name}}</Option>
                    </Select></p>
                <Button style="margin-right:20px" icon="ios-search" type="primary" @click="getData()">搜索</Button>
                <Button style="margin-right:20px" type="primary" icon="md-add" @click="handleOpenAdd">新建</Button>
                <Upload action="/" :before-upload="beforeUpload" :show-upload-list="false">
                    <Button type="primary" icon="ios-cloud-upload-outline">导入</Button>
                </Upload>
            </div>
            <div class="ivu-inline-block ivu-fr">
                <Dropdown trigger="click">
                    <Tooltip class="ivu-ml" content="列设置" placement="top">
                        <i-link>
                            <Icon type="md-options" />
                        </i-link>
                    </Tooltip>
                    <DropdownMenu slot="list">
                        <div class="ivu-p-8">
                            <Row>
                                <Col span="12">列展示</Col>
                                <Col span="12" class="ivu-text-right">
                                    <i-link link-color @click.native="handleResetColumn">重置</i-link>
                                </Col>
                            </Row>
                        </div>
                        <Divider size="small" class="ivu-mt-8 ivu-mb-8" />
                        <li class="ivu-dropdown-item" v-for="item in columns" :key="item.title"  @click="item.show = !item.show">
                            <Checkbox v-model="item.show"></Checkbox>
                            <span>{{ item.title }}</span>
                        </li>
                    </DropdownMenu>
                </Dropdown>
            </div>
            <List item-layout="vertical" style="margin-top:30px">
                <Table  :columns="tableColumns" border :data="data" :loading="loading">
                    <template slot-scope="{ row }" slot="status">
                        <Switch v-model="row.status" @on-change="statusChange(row)">
                            <span slot="close">禁</span>
                            <span slot="open">启</span>
                        </Switch>
                    </template>
                    <template slot-scope="{ row }" slot="link">
                        <p v-if="row.contacts">{{row.contacts}}</p>
                        <p v-if="row.phone">{{row.phone}}</p>
                    </template>
                    <template slot-scope="{ row }" slot="action">
                        <Button type="primary" size="small" style="margin-right: 5px" @click="edit(row)">编辑</Button>
                        <Button type="error" size="small" @click="remove(row.id,row.name)">删除</Button>
                    </template>
                </Table>
                <div class="ivu-mt ivu-text-center" slot="footer">
                    <Page :current.sync="page" :total="count" :pageSize="pageSize" show-total show-elevator :simple="isMobile" @on-change="getData()"></Page>
                </div>
            </List>
        </Card>
        <Modal v-model="showModel" :title="title" :loading="creating" @on-ok="actionEnterprise" :width="1000" :transfer="false">
            <Form ref="infoData" :model="infoData" :rules="addRules" :label-width="120">
                <Row :gutter="30">
                    <Col span="10">
                        <FormItem label="企业名称：" prop="name">
                            <Input v-model="infoData.name" placeholder="请输入企业名称" />
                        </FormItem>
                        <FormItem label="社会统一代码：" prop="id_no">
                            <Input v-model="infoData.id_no" placeholder="请输入社会统一代码" />
                        </FormItem>
                        <FormItem label="管理单位/园区：" prop="belong_unit">
                            <Input v-model="infoData.belong_unit" placeholder="请输入管理单位/园区" />
                        </FormItem>
                        <FormItem label="行业：" prop="industry_id">
                            <Select v-model="infoData.industry_id">
                                <Option v-for="item in industryData" v-bind:key="item.id" :value="item.id">{{item.name}}</Option>
                            </Select>
                        </FormItem>
                        <FormItem label="联系人：" prop="contacts">
                            <Input v-model="infoData.contacts" placeholder="请输入联系人" />
                        </FormItem>
                        <FormItem label="电话：" prop="phone">
                            <Input v-model="infoData.phone" placeholder="请输入电话" />
                        </FormItem>
                        <FormItem label="详细地址：" prop="address">
                            <Input v-model="infoData.address" placeholder="请输入详细地址" />
                        </FormItem>
                    </Col>
                    <Col span="14">
                        <FormItem label="位置坐标：" prop="coordinate">
                            经度：<Input style="width:150px" v-model="infoData.longitude" placeholder="请输入经度" />
                            纬度：<Input style="width:150px" v-model="infoData.latitude" placeholder="请输入纬度" />
                        </FormItem>
                        <div style="width:100%;height:350px;">
                            <el-amap :zoom="10" :center="center" :events="events" mapStyle="light">
                                <el-amap-marker v-if="markerPosition" :position="markerPosition" ></el-amap-marker>
                            </el-amap>
                        </div>
                    </Col>
                </Row>
            </Form>
        </Modal>
    </div>
</template>
<script>
    import { mapState } from 'vuex';
    import { enterpriseList, enterpriseAdd, enterpriseDelete, enterpriseUpdate, industrySelect, enterpriseImport } from '@api/enterprise';

    export default {
        name: 'enterprise_list',
        data () {
            let self = this;
            return {
                name: '',
                id_no: '',
                industry_id: '',
                industryData: [],
                data: [],
                loading: false,
                page: 1,
                count: 0,
                pageSize: 10,
                columns: [
                    {
                        show: true,
                        title: '企业名称',
                        key: 'name'
                    },
                    {
                        show: true,
                        title: '社会统一代码',
                        key: 'id_no',
                        width: 180
                    },
                    {
                        show: true,
                        title: '行业',
                        key: 'industry_name',
                        width: 150
                    },
                    {
                        show: true,
                        title: '主管单位/园区',
                        key: 'belong_unit'
                    },
                    {
                        show: true,
                        title: '地址',
                        key: 'address',
                        width: 250
                    },
                    {
                        show: true,
                        title: '联系方式',
                        slot: 'link',
                        width: 150
                    },
                    {
                        show: true,
                        title: '状态',
                        slot: 'status',
                        width: 100
                    },
                    {
                        show: true,
                        title: '创建时间',
                        key: 'add_time',
                        width: 180
                    },
                    {
                        show: true,
                        title: '操作',
                        slot: 'action',
                        width: 150
                    }
                ],
                showModel: false,
                title: '',
                infoData: {
                    name: '',
                    id_no: '',
                    industry_id: '',
                    belong_unit: '',
                    contacts: '',
                    phone: '',
                    address: '',
                    longitude: '',
                    latitude: ''
                },
                addRules: {
                    name: [
                        { required: true, message: '请输入企业名称', trigger: 'blur' }
                    ]
                },
                creating: true,
                updateIndex: -1,
                updateId: '',
                center: [113.554177, 23.088718],
                events: {
                    click (e) {
                        let { lng, lat } = e.lnglat
                        self.markerPosition = [lng, lat]
                        self.infoData.longitude = lng;
                        self.infoData.latitude = lat
                    }
                },
                markerPosition: ''
            }
        },
        computed: {
            ...mapState('admin/layout', [
                'isMobile'
            ]),
            // 动态设置列
            tableColumns () {
                const columns = [...this.columns];
                return columns.filter(item => item.show);
            }
        },
        methods: {
            // 行业列表
            async getIndustryData () {
                let res = await industrySelect();
                if (res.errno === 0) {
                    this.industryData = res.data
                } else {
                    this.$Message['error']({
                        content: res.errmsg,
                        duration: 3
                    });
                };
            },
            // 列表
            async getData () {
                this.loading = true;
                let params = {
                    page: this.page,
                    name: this.name,
                    id_no: this.id_no,
                    industry_id: this.industry_id
                };
                let res = await enterpriseList(params);
                if (res.errno === 0) {
                    let data = res.data.data;
                    for (var i in data) {
                        if (data[i].status === 0) {
                            data[i].status = true
                        } else {
                            data[i].status = false
                        };
                    };
                    this.data = data;
                    this.count = res.data.count;
                    this.pageSize = res.data.pageSize;
                } else {
                    this.$Message['error']({
                        content: res.errmsg,
                        duration: 3
                    });
                };
                this.loading = false;
            },
            // 添加
            handleOpenAdd () {
                this.title = '添加企业';
                this.updateIndex = -1;
                this.infoData = {
                    name: '',
                    id_no: '',
                    industry_id: '',
                    belong_unit: '',
                    contacts: '',
                    phone: '',
                    address: '',
                    longitude: '',
                    latitude: ''
                };
                this.showModel = true;
            },
            // 编辑
            async edit (info) {
                this.title = '编辑企业信息'
                this.updateIndex = info.id;
                this.updateId = info.id;
                this.infoData.name = info.name;
                this.infoData.id_no = info.id_no;
                this.infoData.industry_id = info.industry_id;
                this.infoData.belong_unit = info.belong_unit;
                this.infoData.contacts = info.contacts;
                this.infoData.phone = info.phone;
                this.infoData.address = info.address;
                this.infoData.longitude = info.longitude;
                this.infoData.latitude = info.latitude;
                if (info.longitude && info.latitude) {
                    this.center = [info.longitude, info.latitude]
                    this.markerPosition = [info.longitude, info.latitude]
                }
                this.showModel = true
            },
            async actionEnterprise () {
                this.$refs.infoData.validate(async (valid) => {
                    if (valid) {
                        if (this.updateIndex < 0) {
                            // 新建
                            let res = await enterpriseAdd(this.infoData);
                            if (res.errno === 0) {
                                this.$Message.success(res.data);
                                this.showModel = false;
                                this.getData()
                            } else {
                                this.$Message.error(res.errmsg);
                            }
                        } else {
                            // 修改
                            let updateData = this.infoData;
                            updateData.id = this.updateId;
                            let res = await enterpriseUpdate(updateData);
                            if (res.errno === 0) {
                                this.$Message.success(res.data);
                                this.showModel = false;
                                this.getData()
                            } else {
                                this.$Message.error(res.errmsg);
                            }
                        }
                        this.creating = false;
                        this.$nextTick(() => {
                            this.creating = true;
                        });
                    } else {
                        this.creating = false;
                        this.$nextTick(() => {
                            this.creating = true;
                        });
                    }
                });
            },
            // 删除
            remove (id, name) {
                this.$Modal.confirm({
                    title: '删除企业',
                    content: '确定删除企业' + name + '吗？',
                    onOk: async () => {
                        let res = await enterpriseDelete({ id: id });
                        if (res.errno === 0) {
                            this.$Message.success(res.data);
                            this.getData()
                        } else {
                            this.$Message.error(res.errmsg);
                        }
                    }
                });
            },
            // 禁用启用
            async statusChange (row) {
                let status = 0;
                if (row.status === true) {
                    status = 0;
                };
                let params = {
                    id: row.id,
                    status: status
                }
                let res = await enterpriseUpdate(params);
                if (res.errno === 0) {
                    this.$Message.success(res.data);
                } else {
                    this.$Message.error(res.errmsg);
                }
            },
            beforeUpload (file) {
                let that = this;
                this.$Table.import({
                    type: 'xlsx',
                    file: file,
                    finish: (res) => {
                        let data = res.data;
                        that.import(data)
                    }
                });
                return false;
            },
            async import (data) {
                let res = await enterpriseImport({ data: data });
                if (res.errno === 0) {
                    let msg = '成功添加' + res.data.successCount + '条，失败' + res.data.failCount + '条'
                    this.$Message.success(msg);
                    this.getData()
                } else {
                    this.$Message.error(res.errmsg);
                }
            },
            // 重置表格列设置
            handleResetColumn () {
                this.columns = this.columns.map(item => {
                    const newItem = item;
                    newItem.show = true;
                    return newItem;
                });
            }
        },
        mounted () {
            this.getData();
            this.getIndustryData()
        }
    }
</script>
