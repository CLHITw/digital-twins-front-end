import BasicLayout from '@/layouts/basic-layout';

export default {
    path: '/account',
    component: BasicLayout,
    children: [
        {
            path: '/account/list',
            name: '账户管理',
            meta: {
                title: '账户管理'
            },
            component: () => import('@/pages/account/list')
        }
    ]
};
