import BasicLayout from '@/layouts/basic-layout';

const meta = {
    auth: true
};

// const pre = 'dashboard-';

export default {
    path: '/dashboard',
    name: 'dashboard',
    redirect: {
        name: `主页`
    },
    meta,
    component: BasicLayout,
    children: [
        {
            path: 'console',
            name: `主页`,
            meta: {
                ...meta,
                title: '主页',
                closable: false
            },
            component: () => import('@/pages/dashboard/console')
        }
    ]
};
