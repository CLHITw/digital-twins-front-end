import BasicLayout from '@/layouts/basic-layout';

export default {
    path: '/statisticalAnalysis',
    component: BasicLayout,
    children: [
        {
            path: '/statisticalAnalysis/enterprise',
            name: '污染源企业',
            meta: {
                title: '污染源企业'
            },
            component: () => import('@/pages/statisticalAnalysis/enterprise')
        },
        {
            path: '/statisticalAnalysis/pollutionSource',
            name: '污染源',
            meta: {
                title: '污染源'
            },
            component: () => import('@/pages/statisticalAnalysis/pollutionSource')
        },
        {
            path: '/statisticalAnalysis/monitorNode',
            name: '监测点',
            meta: {
                title: '监测点'
            },
            component: () => import('@/pages/statisticalAnalysis/monitorNode')
        }
    ]
};
