import BasicLayout from '@/layouts/basic-layout';

export default {
    path: '/sourceCalculate',
    component: BasicLayout,
    children: [
        {
            path: '/sourceCalculate/contaminant',
            name: '指标溯源',
            meta: {
                title: '指标溯源'
            },
            component: () => import('@/pages/sourceCalculate/contaminant')
        },
        {
            path: '/sourceCalculate/fluorescence',
            name: '荧光溯源',
            meta: {
                title: '荧光溯源'
            },
            component: () => import('@/pages/sourceCalculate/fluorescence')
        }
    ]
};
