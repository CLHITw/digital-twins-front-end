import BasicLayout from '@/layouts/basic-layout';

export default {
    path: '/monitorNodeFiles',
    component: BasicLayout,
    children: [
        {
            path: '/monitorNodeFiles/baseInfo',
            name: '监测点基本信息',
            meta: {
                title: '监测点基本信息'
            },
            component: () => import('@/pages/monitorNodeFiles/baseInfo')
        },
        {
            path: '/monitorNodeFiles/contaminant',
            name: '常规水质监测',
            meta: {
                title: '常规水质监测'
            },
            component: () => import('@/pages/monitorNodeFiles/contaminant')
        },
        {
            path: '/monitorNodeFiles/contaminant1',
            name: '挥发性有机物监测',
            meta: {
                title: '挥发性有机物监测'
            },
            component: () => import('@/pages/monitorNodeFiles/contaminant1')
        },
        {
            path: '/monitorNodeFiles/contaminant2',
            name: '重金属监测',
            meta: {
                title: '重金属监测'
            },
            component: () => import('@/pages/monitorNodeFiles/contaminant2')
        },
        {
            path: '/monitorNodeFiles/fluorescence',
            name: '荧光光谱监测',
            meta: {
                title: '荧光光谱监测'
            },
            component: () => import('@/pages/monitorNodeFiles/fluorescence')
        }
    ]
};
