import BasicLayout from '@/layouts/basic-layout';

export default {
    path: '/pollutionSourceFiles',
    component: BasicLayout,
    children: [
        {
            path: '/pollutionSourceFiles/baseInfo',
            name: '污染源基本信息',
            meta: {
                title: '污染源基本信息'
            },
            component: () => import('@/pages/pollutionSourceFiles/baseInfo')
        },
        {
            path: '/pollutionSourceFiles/contaminant',
            name: '常规水质指标',
            meta: {
                title: '常规水质指标'
            },
            component: () => import('@/pages/pollutionSourceFiles/contaminant')
        },
        {
            path: '/pollutionSourceFiles/contaminant1',
            name: '挥发性有机物指标',
            meta: {
                title: '挥发性有机物指标'
            },
            component: () => import('@/pages/pollutionSourceFiles/contaminant1')
        },
        {
            path: '/pollutionSourceFiles/contaminant2',
            name: '重金属指标',
            meta: {
                title: '重金属指标'
            },
            component: () => import('@/pages/pollutionSourceFiles/contaminant2')
        },
        {
            path: '/pollutionSourceFiles/fluorescence',
            name: '荧光光谱指标',
            meta: {
                title: '荧光光谱指标'
            },
            component: () => import('@/pages/pollutionSourceFiles/fluorescence')
        }
    ]
};
