import BasicLayout from '@/layouts/basic-layout';

export default {
    path: '/pollutionSourceDirectory',
    component: BasicLayout,
    children: [
        {
            path: '/pollutionSourceDirectory/enterprise',
            name: '企业基本信息',
            meta: {
                title: '企业基本信息'
            },
            component: () => import('@/pages/pollutionSourceDirectory/enterprise')
        },
        {
            path: '/pollutionSourceDirectory/outlet',
            name: '企业排污口',
            meta: {
                title: '企业排污口'
            },
            component: () => import('@/pages/pollutionSourceDirectory/outlet')
        },
        {
            path: '/pollutionSourceDirectory/yearsData',
            name: '企业环保数据',
            meta: {
                title: '企业环保数据'
            },
            component: () => import('@/pages/pollutionSourceDirectory/yearsData')
        }
    ]
};
