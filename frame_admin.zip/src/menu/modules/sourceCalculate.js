const pre = '/sourceCalculate';

export default {
    path: '/sourceCalculate',
    title: '溯源计算',
    header: 'home',
    icon: 'ios-cloud',
    children: [
        {
            path: `${pre}/contaminant`,
            title: '指标溯源'
        },
        {
            path: `${pre}/fluorescence`,
            title: '荧光溯源'
        }
    ]
}
