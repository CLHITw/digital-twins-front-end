export default {
    path: '/account/list',
    title: '账户管理',
    header: 'home',
    icon: 'ios-people'
}
