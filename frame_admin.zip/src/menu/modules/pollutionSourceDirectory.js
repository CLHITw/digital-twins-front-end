const pre = '/pollutionSourceDirectory';

export default {
    path: '/pollutionSourceDirectory',
    title: '企业档案',
    header: 'home',
    icon: 'ios-bookmarks',
    children: [
        {
            path: `${pre}/enterprise`,
            title: '企业基本信息'
        },
        {
            path: `${pre}/outlet`,
            title: '企业排污口'
        },
        {
            path: `${pre}/yearsData`,
            title: '企业环保数据'
        }
    ]
}
