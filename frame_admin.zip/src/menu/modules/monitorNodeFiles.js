const pre = '/monitorNodeFiles';

export default {
    path: '/monitorNodeFiles',
    title: '监测点档案',
    header: 'home',
    icon: 'ios-apps',
    children: [
        {
            path: `${pre}/baseInfo`,
            title: '监测点基本信息'
        },
        {
            path: `${pre}/contaminant`,
            title: '常规水质监测'
        },
        {
            path: `${pre}/contaminant1`,
            title: '挥发性有机物监测'
        },
        {
            path: `${pre}/contaminant2`,
            title: '重金属监测'
        },
        {
            path: `${pre}/fluorescence`,
            title: '荧光光谱监测'
        }
    ]
}
