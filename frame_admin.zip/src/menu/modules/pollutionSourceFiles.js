const pre = '/pollutionSourceFiles';

export default {
    path: '/pollutionSourceFiles',
    title: '污染源档案',
    header: 'home',
    icon: 'ios-folder',
    children: [
        {
            path: `${pre}/baseInfo`,
            title: '污染源基本信息'
        },
        {
            path: `${pre}/contaminant`,
            title: '常规水质指标'
        },
        {
            path: `${pre}/contaminant1`,
            title: '挥发性有机物指标'
        },
        {
            path: `${pre}/contaminant2`,
            title: '重金属指标'
        }
        // {
        //     path: `${pre}/fluorescence`,
        //     title: '荧光光谱指标'
        // }
    ]
}
