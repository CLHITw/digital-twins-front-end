export default {
    path: '/dashboard/console',
    title: '主页',
    header: 'home',
    icon: 'ios-home'
}
