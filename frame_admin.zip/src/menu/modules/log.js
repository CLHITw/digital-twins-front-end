export default {
    path: '/log',
    title: '前端日志',
    header: 'system',
    icon: 'md-locate'
}
