const pre = '/statisticalAnalysis';

export default {
    path: '/statisticalAnalysis',
    title: '统计分析',
    header: 'home',
    icon: 'ios-pie',
    children: [
        {
            path: `${pre}/enterprise`,
            title: '企业'
        },
        {
            path: `${pre}/pollutionSource`,
            title: '污染源'
        },
        {
            path: `${pre}/monitorNode`,
            title: '监测点'
        }
    ]
}
