// 菜单，侧边栏
import dashboard from './modules/dashboard';
import account from './modules/account';
import pollutionSourceDirectory from './modules/pollutionSourceDirectory';
import pollutionSourceFiles from './modules/pollutionSourceFiles';
import monitorNodeFiles from './modules/monitorNodeFiles';
import statisticalAnalysis from './modules/statisticalAnalysis';
import sourceCalculate from './modules/sourceCalculate';

// 系统
import log from './modules/log';

export default [
    dashboard,
    pollutionSourceDirectory,
    pollutionSourceFiles,
    monitorNodeFiles,
    statisticalAnalysis,
    sourceCalculate,
    account,
    log
];
